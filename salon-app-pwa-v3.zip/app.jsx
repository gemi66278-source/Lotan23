import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { createRoot } from "react-dom/client";
import {
  LuScissors as Scissors,
  LuCalendar as Calendar,
  LuClock as Clock,
  LuUser as User,
  LuPhone as Phone,
  LuPlus as Plus,
  LuTrash2 as Trash2,
  LuCheck as Check,
  LuChevronLeft as ChevronLeft,
  LuChevronRight as ChevronRight,
  LuSearch as Search,
  LuMessageCircle as MessageCircle,
  LuCamera as Camera,
  LuArrowRight as ArrowRight,
  LuX as X,
  LuPenLine as Edit3,
  LuPhoneCall as PhoneCall,
  LuImagePlus as ImagePlus,
  LuCircleAlert as AlertCircle,
  LuWallet as Wallet,
  LuStar as Star,
  LuTrendingDown as TrendingDown,
  LuTrendingUp as TrendingUp,
  LuCrown as Crown,
  LuSettings as SettingsIcon,
  LuDownload as Download,
  LuUpload as Upload,
  LuZap as Zap,
  LuCalendarClock as CalendarClock,
  LuLock as Lock,
  LuLockOpen as Unlock,
  LuShieldCheck as ShieldCheck,
  LuClipboard as Clipboard,
  LuClipboardCheck as ClipboardCheck,
} from "react-icons/lu";

// ---------- ذخیره‌سازی محلی ----------
// این نسخه دیگه داخل محیط Claude اجرا نمی‌شه، پس به‌جای window.storage اختصاصیِ آرتیفکت،
// از حافظه‌ی خود مرورگر/گوشی استفاده می‌کنیم. اطلاعات فقط روی همون گوشی ذخیره می‌مونه؛
// برای همین بخش «پشتیبان‌گیری» تو تنظیمات خیلی مهمه.
//
// نکته‌ی مهم: عکس‌ها (پروفایل مشتری + آرشیو مدل‌های مو) تو IndexedDB ذخیره می‌شن، نه localStorage.
// localStorage معمولاً فقط چند مگابایت جا داره و با گذشت زمان که آرایشگر برای صدها مشتری عکس
// می‌گیره، همون چند مگابایت به‌سرعت پر می‌شه و باعث می‌شه عکس‌های جدید بی‌سروصدا ذخیره نشن.
// IndexedDB برای همین‌جور داده‌ی حجیم ساخته شده و ظرفیتش خیلی بیشتره (معمولاً صدها مگابایت به بالا).
// بقیه‌ی اطلاعات (لیست مشتری‌ها، نوبت‌ها، تنظیمات، خدمات) چون حجم کمی دارن همچنان تو localStorage می‌مونن.
const PHOTO_KEY_PREFIXES = ["barber-photo:", "barber-style-photo:"];
function isPhotoKey(key) { return PHOTO_KEY_PREFIXES.some((p) => String(key).startsWith(p)); }

let _photoDbPromise = null;
function openPhotoDB() {
  if (_photoDbPromise) return _photoDbPromise;
  _photoDbPromise = new Promise((resolve, reject) => {
    if (!("indexedDB" in window)) { reject(new Error("indexeddb-unavailable")); return; }
    const req = indexedDB.open("barbershop-photos-db", 1);
    req.onupgradeneeded = () => { req.result.createObjectStore("photos"); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("indexeddb-open-failed"));
  });
  return _photoDbPromise;
}
function idbGet(key) {
  return openPhotoDB().then((db) => new Promise((resolve, reject) => {
    const req = db.transaction("photos", "readonly").objectStore("photos").get(key);
    req.onsuccess = () => resolve(req.result === undefined ? null : req.result);
    req.onerror = () => reject(req.error);
  }));
}
function idbSet(key, value) {
  return openPhotoDB().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction("photos", "readwrite");
    tx.objectStore("photos").put(value, key);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  }));
}
function idbDelete(key) {
  return openPhotoDB().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction("photos", "readwrite");
    tx.objectStore("photos").delete(key);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  }));
}
function idbListKeys(prefix) {
  return openPhotoDB().then((db) => new Promise((resolve, reject) => {
    const req = db.transaction("photos", "readonly").objectStore("photos").getAllKeys();
    req.onsuccess = () => resolve((req.result || []).map(String).filter((k) => !prefix || k.startsWith(prefix)));
    req.onerror = () => reject(req.error);
  }));
}

window.storage = {
  async get(key) {
    try {
      if (isPhotoKey(key)) {
        try {
          const v = await idbGet(key);
          if (v != null) return { key, value: v, shared: false };
        } catch (e) { /* IndexedDB در دسترس نبود؛ برو سراغ localStorage */ }
        // سازگاری با عکس‌هایی که قبلاً (نسخه‌های قبلی) تو localStorage ذخیره شده بودن؛
        // اگه پیدا بشن، یک‌بار به IndexedDB منتقل می‌شن تا جای localStorage باز بشه.
        const raw = localStorage.getItem(key);
        if (raw !== null) {
          idbSet(key, raw).then(() => { try { localStorage.removeItem(key); } catch (e) {} }).catch(() => {});
          return { key, value: raw, shared: false };
        }
        return null;
      }
      const raw = localStorage.getItem(key);
      return raw === null ? null : { key, value: raw, shared: false };
    } catch (e) { return null; }
  },
  async set(key, value) {
    try {
      if (isPhotoKey(key)) {
        try {
          await idbSet(key, value);
          return { key, value, shared: false };
        } catch (e) {
          // بازگشت اضطراری به localStorage اگه IndexedDB در دسترس نبود (مثلاً حالت خصوصی بعضی مرورگرها)
          localStorage.setItem(key, value);
          return { key, value, shared: false };
        }
      }
      localStorage.setItem(key, value);
      return { key, value, shared: false };
    } catch (e) { return null; }
  },
  async delete(key) {
    try {
      if (isPhotoKey(key)) {
        try { await idbDelete(key); } catch (e) {}
        try { localStorage.removeItem(key); } catch (e) {}
        return { key, deleted: true, shared: false };
      }
      localStorage.removeItem(key);
      return { key, deleted: true, shared: false };
    } catch (e) { return null; }
  },
  async list(prefix) {
    try {
      if (!prefix || PHOTO_KEY_PREFIXES.some((p) => p.startsWith(prefix) || prefix.startsWith(p))) {
        const idbKeys = await idbListKeys(prefix).catch(() => []);
        const lsKeys = Object.keys(localStorage).filter((k) => !prefix || k.startsWith(prefix));
        const keys = Array.from(new Set([...idbKeys, ...lsKeys]));
        return { keys, prefix, shared: false };
      }
      const keys = Object.keys(localStorage).filter((k) => !prefix || k.startsWith(prefix));
      return { keys, prefix, shared: false };
    } catch (e) { return null; }
  },
};

// ---------- Jalali (Persian) calendar ----------
function div(a, b) { return ~~(a / b); }
function gregorianToJalali(gy, gm, gd) {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + div(gy2 + 3, 4) - div(gy2 + 99, 100) + div(gy2 + 399, 400) - 80 + gd + g_d_m[gm - 1];
  jy += 33 * div(days, 12053);
  days %= 12053;
  jy += 4 * div(days, 1461);
  days %= 1461;
  if (days > 365) { jy += div(days - 1, 365); days = (days - 1) % 365; }
  const jm = days < 186 ? 1 + div(days, 31) : 7 + div(days - 186, 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}
const JALALI_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
const WEEKDAYS = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
const WEEKDAYS_SHORT = ["ی", "د", "س", "چ", "پ", "ج", "ش"];

function toDateStr(d) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; }
// همه‌ی رشته‌های تاریخ توی این برنامه به فرم YYYY-MM-DD هستن. نباید مستقیم new Date(str) بشن،
// چون مرورگر این رشته‌ها رو ساعت ۰۰:۰۰ UTC می‌خونه نه نیمه‌شب محلی؛ همین می‌تونه باعث بشه
// نزدیک نیمه‌شب یا توی منطقه‌های زمانی دیگه، تاریخ یک روز جابه‌جا بشه. برای همین همیشه از این تابع استفاده می‌کنیم.
function parseLocalDate(dateStr) {
  const [y, m, d] = String(dateStr).split("-").map(Number);
  return new Date(y || 1970, (m || 1) - 1, d || 1);
}
function jalaliLabel(d) {
  const [jy, jm, jd] = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  return { jy, jm, jd, monthName: JALALI_MONTHS[jm - 1], weekday: WEEKDAYS[d.getDay()], weekdayShort: WEEKDAYS_SHORT[d.getDay()] };
}
function toFa(str) { const fa = ["۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"]; return String(str).replace(/[0-9]/g, (d) => fa[d]); }
function formatToman(n) { return toFa(Math.round(n || 0).toLocaleString("en-US")); }
function minutesToLabel(mins) { const h = Math.floor(mins / 60), m = mins % 60; return toFa(`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`); }
function timeToMinutes(t) { const [h, m] = t.split(":").map(Number); return h * 60 + m; }
function daysBetween(a, b) { return Math.round((parseLocalDate(b) - parseLocalDate(a)) / 86400000); }
function addDays(dateStr, n) { const d = parseLocalDate(dateStr); d.setDate(d.getDate() + n); return toDateStr(d); }
// یک نوبت را «انجام‌شده» حساب می‌کنیم اگر صراحتاً علامت خورده باشد،
// یا (برای سازگاری با داده‌های قبلی) تاریخش گذشته و لغو نشده باشد.
function isCompletedAppt(a, today) {
  if (a.status === "canceled") return false;
  if (a.status === "done") return true;
  return a.status == null && a.date < today;
}
function cutDateOf(a) { return a.doneAt || a.date; }
function priceOfAppt(a, services) {
  if (typeof a.price === "number") return a.price;
  const sv = services.find((s) => s.id === a.serviceId);
  return sv?.price || 0;
}
function lastCutInfo(customerId, appointments, today) {
  const done = appointments.filter((a) => a.customerId === customerId && isCompletedAppt(a, today));
  if (done.length === 0) return null;
  done.sort((a, b) => cutDateOf(b).localeCompare(cutDateOf(a)));
  return cutDateOf(done[0]);
}
// نوبت‌های آینده‌ی یک مشتری که هنوز انجام نشده و کنسل نشده؛ برای جلوگیری از رزرو تکراری استفاده می‌شه
function upcomingApptsOf(customerId, appointments, today, excludeApptId) {
  return appointments
    .filter((a) => a.customerId === customerId && a.id !== excludeApptId && a.date >= today && a.status !== "done" && a.status !== "canceled")
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
}
// دوره واقعی اصلاح هر مشتری رو از روی فاصله بین اصلاح‌های قبلی‌اش حساب می‌کنیم؛
// با یک بار مراجعه هنوز چیزی معلوم نیست، از دو بار به بعد میانگین فاصله‌ها رو برمی‌گردونیم.
function estimateCycleDays(customerId, appointments, today) {
  const dates = appointments
    .filter((a) => a.customerId === customerId && isCompletedAppt(a, today))
    .map((a) => cutDateOf(a))
    .sort((a, b) => a.localeCompare(b));
  if (dates.length < 2) return null;
  let total = 0, count = 0;
  for (let i = 1; i < dates.length; i++) {
    const diff = daysBetween(dates[i - 1], dates[i]);
    if (diff > 0) { total += diff; count++; }
  }
  if (count === 0) return null;
  return Math.round(total / count);
}

const DEFAULT_SERVICES = [
  { id: "sv1", name: "کوتاهی مو", duration: 30, price: 150000 },
  { id: "sv2", name: "اصلاح صورت", duration: 15, price: 80000 },
  { id: "sv3", name: "کوتاهی + اصلاح", duration: 40, price: 200000 },
  { id: "sv4", name: "رنگ مو", duration: 60, price: 350000 },
  { id: "sv5", name: "پیرایش کامل", duration: 50, price: 280000 },
];
const DEFAULT_WEEK_HOURS = {
  0: { closed: false, start: "10:00", end: "21:00" },
  1: { closed: false, start: "10:00", end: "21:00" },
  2: { closed: false, start: "10:00", end: "21:00" },
  3: { closed: false, start: "10:00", end: "21:00" },
  4: { closed: false, start: "10:00", end: "21:00" },
  5: { closed: false, start: "10:00", end: "21:00" },
  6: { closed: false, start: "10:00", end: "21:00" },
};
const DEFAULT_SETTINGS = { shopName: "پیرایش مردانه", weekHours: DEFAULT_WEEK_HOURS };
function normalizeSettings(raw) {
  if (!raw || typeof raw !== "object") return DEFAULT_SETTINGS;
  // سازگاری با نسخه قبلی که فقط { start, end } ذخیره می‌کرد
  if (raw.start && raw.end && !raw.weekHours) {
    const wh = {};
    for (let i = 0; i < 7; i++) wh[i] = { closed: false, start: raw.start, end: raw.end };
    return { ...DEFAULT_SETTINGS, weekHours: wh };
  }
  const wh = { ...DEFAULT_WEEK_HOURS, ...(raw.weekHours || {}) };
  return { shopName: raw.shopName || DEFAULT_SETTINGS.shopName, weekHours: wh };
}
const K_CUSTOMERS = "barber-customers-v1";
const K_APPTS = "barber-appointments-v1";
const K_SETTINGS = "barber-settings-v1";
const K_SERVICES = "barber-services-v1";
const K_PHOTO = (id) => `barber-photo:${id}`;
// هر مدل مویی که برای مشتری ثبت می‌شه یک عکس جدا داره (آرشیو شبیه پروفایل اینستاگرام)
const K_STYLE_PHOTO = (customerId, entryId) => `barber-style-photo:${customerId}:${entryId}`;

function uid() { return Math.random().toString(36).slice(2, 10); }

// ---------- استخراج خودکار شماره تلفن از متن (کلیپ‌بورد یا اشتراک‌گذاری از لیست تماس‌ها) ----------
function extractPhoneNumber(text) {
  if (!text) return "";
  const cleaned = String(text).replace(/[\u200c\s\-().]/g, "");
  const match = cleaned.match(/(\+?98|0)?9\d{9}/);
  if (!match) return "";
  let num = match[0].replace(/^\+?98/, "0");
  if (!num.startsWith("0")) num = "0" + num;
  return num;
}

// ---------- ثبت سریع تلفنی: اسم پیش‌فرض غیرتکراری ----------
const PENDING_NAME_PREFIX = "مشتری تلفنی ";
function isPendingName(name) { return typeof name === "string" && name.startsWith(PENDING_NAME_PREFIX); }
function generatePendingName(customers) {
  const existing = new Set(customers.map((c) => c.name));
  let n = 1;
  while (existing.has(PENDING_NAME_PREFIX + toFa(n))) n++;
  return PENDING_NAME_PREFIX + toFa(n);
}

// ---------- محاسبه‌ی ساعت‌های خالی؛ هم تو فرم نوبت‌دهی و هم تو ثبت سریع تلفنی استفاده می‌شه ----------
function computeDaySlots({ date, service, services, weekHours, appointments, excludeApptId, now }) {
  const dayCfg = weekHours?.[parseLocalDate(date).getDay()] || { closed: false, start: "10:00", end: "21:00" };
  if (!service || dayCfg.closed) return [];
  const startMin = timeToMinutes(dayCfg.start), endMin = timeToMinutes(dayCfg.end);
  const isToday = date === toDateStr(now);
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const dayAppts = appointments.filter((a) => a.date === date && a.id !== excludeApptId);
  const busy = dayAppts.map((a) => {
    const sv = services.find((s) => s.id === a.serviceId);
    const start = timeToMinutes(a.time);
    return { start, end: start + (sv?.duration || 30) };
  });
  const result = [];
  for (let t = startMin; t + service.duration <= endMin; t += 15) {
    if (isToday && t <= nowMin) continue;
    const tEnd = t + service.duration;
    if (!busy.some((b) => t < b.end && tEnd > b.start)) result.push(t);
  }
  return result;
}
// نزدیک‌ترین وقت خالی رو تا ۱۴ روز آینده پیدا می‌کنه
function findNextAvailableSlot({ service, services, weekHours, appointments, now, maxDays = 14 }) {
  for (let i = 0; i < maxDays; i++) {
    const d = new Date(now);
    d.setDate(d.getDate() + i);
    const dateStr = toDateStr(d);
    const slots = computeDaySlots({ date: dateStr, service, services, weekHours, appointments, now });
    if (slots.length > 0) return { date: dateStr, time: slots[0] };
  }
  return null;
}
// برای «نوبت بعدی همین مشتری»: از یک تاریخ مشخص (مثلاً ۵ روز دیگه) شروع می‌کنه و اگه اون روز جا نبود چند روز بعدش رو هم می‌گرده؛
// در بین ساعت‌های خالی، نزدیک‌ترین به ساعت همیشگی مشتری رو ترجیح می‌ده
function findSlotOnOrAfter({ date, service, services, weekHours, appointments, now, preferredTime, maxDays = 7 }) {
  for (let i = 0; i < maxDays; i++) {
    const d = parseLocalDate(date);
    d.setDate(d.getDate() + i);
    const dateStr = toDateStr(d);
    const slots = computeDaySlots({ date: dateStr, service, services, weekHours, appointments, now });
    if (slots.length > 0) {
      let chosen = slots[0];
      if (preferredTime != null) {
        chosen = slots.reduce((best, t) => (Math.abs(t - preferredTime) < Math.abs(best - preferredTime) ? t : best), slots[0]);
      }
      return { date: dateStr, time: chosen };
    }
  }
  return null;
}

function resizeImageFile(file, maxSize = 480) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxSize) { height = Math.round(height * (maxSize / width)); width = maxSize; }
        else if (height > maxSize) { width = Math.round(width * (maxSize / height)); height = maxSize; }
        const canvas = document.createElement("canvas");
        canvas.width = width; canvas.height = height;
        canvas.getContext("2d").drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function BarberApp() {
  const [loaded, setLoaded] = useState(false);
  const [customers, setCustomers] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [services, setServices] = useState(DEFAULT_SERVICES);
  const [toast, setToast] = useState(null);

  const [tab, setTab] = useState("today");
  const [screen, setScreen] = useState("main"); // main | newCustomer | booking | editBooking | detail | settings
  const [activeCustomerId, setActiveCustomerId] = useState(null);
  const [editingApptId, setEditingApptId] = useState(null);
  const [phoneCaptureOpen, setPhoneCaptureOpen] = useState(false);
  const [sharedPhone, setSharedPhone] = useState("");

  // اگه آرایشگر از لیست تماس‌های گوشی روی یک شماره «اشتراک‌گذاری/Share» بزنه و این اپ رو انتخاب کنه،
  // مرورگر آدرس رو با ?shared_text=... باز می‌کنه؛ اینجا شماره رو استخراج می‌کنیم و مستقیم فرم رو باز می‌کنیم.
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const sharedRaw = params.get("shared_text") || params.get("shared_title") || params.get("shared_url") || "";
      if (sharedRaw) {
        const num = extractPhoneNumber(decodeURIComponent(sharedRaw));
        if (num) { setSharedPhone(num); setPhoneCaptureOpen(true); }
        window.history.replaceState({}, "", window.location.pathname);
      }
      // میان‌برهای اپ (Shortcuts) روی آدرس ?tab=... باز می‌شن؛ اینجا همون تب رو فعال می‌کنیم.
      const wantedTab = params.get("tab");
      const validTabs = ["today", "income", "customers", "loyal", "cycle", "followup"];
      if (wantedTab && validTabs.includes(wantedTab)) {
        setTab(wantedTab);
        window.history.replaceState({}, "", window.location.pathname);
      }
    } catch (e) {}
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const c = await window.storage.get(K_CUSTOMERS, false);
        if (c?.value) setCustomers(JSON.parse(c.value));
      } catch (e) {}
      try {
        const a = await window.storage.get(K_APPTS, false);
        if (a?.value) setAppointments(JSON.parse(a.value));
      } catch (e) {}
      try {
        const s = await window.storage.get(K_SETTINGS, false);
        if (s?.value) setSettings(normalizeSettings(JSON.parse(s.value)));
      } catch (e) {}
      try {
        const sv = await window.storage.get(K_SERVICES, false);
        if (sv?.value) {
          const parsed = JSON.parse(sv.value);
          if (Array.isArray(parsed) && parsed.length) setServices(parsed);
        }
      } catch (e) {}
      setLoaded(true);
    })();
  }, []);

  useEffect(() => { if (loaded) window.storage.set(K_CUSTOMERS, JSON.stringify(customers), false).catch(() => {}); }, [customers, loaded]);
  useEffect(() => { if (loaded) window.storage.set(K_APPTS, JSON.stringify(appointments), false).catch(() => {}); }, [appointments, loaded]);
  useEffect(() => { if (loaded) window.storage.set(K_SETTINGS, JSON.stringify(settings), false).catch(() => {}); }, [settings, loaded]);
  useEffect(() => { if (loaded) window.storage.set(K_SERVICES, JSON.stringify(services), false).catch(() => {}); }, [services, loaded]);

  const showToast = useCallback((msg) => { setToast(msg); setTimeout(() => setToast(null), 2600); }, []);

  const goMain = (t) => { setScreen("main"); setActiveCustomerId(null); setEditingApptId(null); if (t) setTab(t); };

  const activeCustomer = customers.find((c) => c.id === activeCustomerId);
  const editingAppt = editingApptId ? appointments.find((a) => a.id === editingApptId) : null;

  // وقتی مشتری حذف می‌شه، عکس‌هاش (پروفایل + آرشیو مدل‌های مو) هم باید از حافظه پاک بشن،
  // وگرنه با گذشت زمان حافظه گوشی بی‌دلیل پر می‌شه از عکس‌هایی که هیچ‌جا نمایش داده نمی‌شن.
  // نوبت‌های قبلی این مشتری عمداً حذف نمی‌شن تا آمار درآمد گذشته درست بمونه (به‌عنوان «مشتری حذف‌شده» نشون داده می‌شن).
  const deleteCustomer = useCallback((id) => {
    const c = customers.find((x) => x.id === id);
    if (c?.hasPhoto) window.storage.delete(K_PHOTO(id)).catch(() => {});
    (c?.styleHistory || []).forEach((entry) => {
      if (entry.hasPhoto) window.storage.delete(K_STYLE_PHOTO(id, entry.id)).catch(() => {});
    });
    setCustomers((p) => p.filter((x) => x.id !== id));
    goMain("customers");
    showToast("مشتری حذف شد");
  }, [customers, showToast]);

  const restoreBackup = useCallback((data) => {
    if (data.customers) setCustomers(data.customers);
    if (data.appointments) setAppointments(data.appointments);
    if (data.settings) setSettings(normalizeSettings(data.settings));
    if (data.services && Array.isArray(data.services) && data.services.length) setServices(data.services);
    if (data.photos && typeof data.photos === "object") {
      Object.entries(data.photos).forEach(([k, v]) => { if (typeof v === "string") window.storage.set(k, v, false).catch(() => {}); });
    }
    showToast("نسخه پشتیبان بازیابی شد");
  }, [showToast]);

  return (
    <div dir="rtl" lang="fa"
      style={{ fontFamily: "'Vazirmatn', Tahoma, 'Segoe UI', system-ui, sans-serif", "--bg": "#F3EFE7", "--surface": "#FFFFFF", "--ink": "#22262B",
        "--primary": "#1C2B39", "--primary-light": "#33495D", "--accent": "#B8863B", "--accent-light": "#EFDFB8",
        "--muted": "#75726B", "--border": "#E3DDCB" }}
      className="min-h-screen w-full">
      <style>{`
        /* فونت از فایل محلی (styles/vazirmatn.css) لود می‌شه، نه از گوگل فونت -
           چون fonts.googleapis.com معمولاً بدون فیلترشکن باز نمی‌شه و باعث می‌شد کل اپ بالا نیاد. */
        .bshop * { box-sizing: border-box; }
        .bshop { background: var(--bg); color: var(--ink); min-height:100vh; }
        .card {
          background: var(--surface); border: 1px solid var(--border); border-radius: 18px;
          box-shadow: 0 1px 2px rgba(28,43,57,.03), 0 10px 24px -18px rgba(28,43,57,.35);
          transition: box-shadow .2s ease, transform .2s ease;
        }
        button { -webkit-tap-highlight-color: transparent; }
        button:not(:disabled) { cursor: pointer; }
        .btn-primary, .btn-gold {
          transition: transform .12s ease, background .15s ease, box-shadow .15s ease, opacity .15s ease;
          box-shadow: 0 6px 16px -6px rgba(28,43,57,.4);
        }
        .btn-primary:active:not(:disabled), .btn-gold:active:not(:disabled) { transform: scale(.97); box-shadow: 0 2px 8px -4px rgba(28,43,57,.35); }
        .btn-primary { background: var(--primary); color:#fff; }
        .btn-primary:hover:not(:disabled) { background: var(--primary-light); }
        .btn-primary:disabled { opacity:.4; box-shadow:none; }
        .btn-gold { background: var(--accent); color:#2A2115; box-shadow: 0 6px 16px -6px rgba(184,134,59,.5); }
        .btn-gold:hover:not(:disabled) { filter: brightness(1.05); }
        .btn-gold:disabled { opacity:.45; box-shadow:none; }
        .slot-btn { transition: all .15s ease; }
        .slot-btn:hover:not(:disabled) { border-color: var(--primary); background: var(--primary); color:#fff; }
        .slot-btn:active:not(:disabled) { transform: scale(.96); }
        .fade-in { animation: fadeIn .3s ease; }
        @keyframes fadeIn { from{opacity:0; transform:translateY(6px);} to{opacity:1; transform:translateY(0);} }
        .pole-stripe { height:5px; width:100%; background: repeating-linear-gradient(-45deg, var(--accent) 0 10px, var(--primary) 10px 20px, var(--surface) 20px 24px); border-radius: 4px; opacity:.85; }
        .no-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        input, textarea { outline: none; transition: border-color .15s ease, box-shadow .15s ease; }
        input:focus, textarea:focus { border-color: var(--primary) !important; box-shadow: 0 0 0 3px rgba(28,43,57,.08); }
      `}</style>

      <div className="bshop">
        <Header shopName={settings.shopName} onLogo={() => goMain("today")} onSettings={() => { setScreen("settings"); }} />
        <div className="pole-stripe" />

        {screen === "main" && (
          <>
            <TabBar tab={tab} setTab={setTab} />
            {tab === "today" && (
              <TodayTab appointments={appointments} customers={customers} services={services} weekHours={settings.weekHours}
                setAppointments={setAppointments} setCustomers={setCustomers} showToast={showToast}
                onOpenCustomer={(id) => { setActiveCustomerId(id); setScreen("detail"); }}
                onEditAppt={(id) => { const a = appointments.find((x) => x.id === id); setActiveCustomerId(a.customerId); setEditingApptId(id); setScreen("editBooking"); }} />
            )}
            {tab === "income" && (
              <IncomeTab appointments={appointments} customers={customers} services={services} />
            )}
            {tab === "customers" && (
              <CustomersTab customers={customers} appointments={appointments}
                onAddNew={() => setScreen("newCustomer")}
                onOpenCustomer={(id) => { setActiveCustomerId(id); setScreen("detail"); }}
                onBook={(id) => { setActiveCustomerId(id); setScreen("booking"); }} />
            )}
            {tab === "loyal" && (
              <LoyalTab customers={customers} appointments={appointments} services={services}
                onOpenCustomer={(id) => { setActiveCustomerId(id); setScreen("detail"); }} />
            )}
            {tab === "cycle" && (
              <CycleTab customers={customers} appointments={appointments}
                onOpenCustomer={(id) => { setActiveCustomerId(id); setScreen("detail"); }}
                onBook={(id) => { setActiveCustomerId(id); setScreen("booking"); }} />
            )}
            {tab === "followup" && (
              <FollowupTab customers={customers} appointments={appointments} showToast={showToast} />
            )}
          </>
        )}

        {screen === "newCustomer" && (
          <NewCustomerFlow
            onCancel={() => goMain()}
            showToast={showToast}
            onSaved={(customer) => { setCustomers((p) => [...p, customer]); setActiveCustomerId(customer.id); setScreen("booking"); showToast("مشتری ذخیره شد"); }} />
        )}

        {screen === "booking" && activeCustomer && (
          <BookingFlow customer={activeCustomer} services={services} weekHours={settings.weekHours} appointments={appointments}
            onCancel={() => goMain("customers")}
            onConfirm={(appt) => { setAppointments((p) => [...p, appt]); showToast("وقت ثبت شد"); goMain("today"); }} />
        )}

        {screen === "editBooking" && activeCustomer && editingAppt && (
          <BookingFlow customer={activeCustomer} services={services} weekHours={settings.weekHours} appointments={appointments}
            editingAppt={editingAppt}
            onCancel={() => goMain("today")}
            onConfirm={(appt) => { setAppointments((p) => p.map((a) => (a.id === appt.id ? appt : a))); showToast("نوبت جابه‌جا شد"); goMain("today"); }} />
        )}

        {screen === "detail" && activeCustomer && (
          <CustomerDetail customer={activeCustomer} appointments={appointments} services={services}
            onBack={() => goMain("customers")}
            onSave={(updated) => setCustomers((p) => p.map((c) => (c.id === updated.id ? updated : c)))}
            onDelete={deleteCustomer}
            onBook={() => setScreen("booking")}
            onEditAppt={(id) => { setEditingApptId(id); setScreen("editBooking"); }}
            showToast={showToast} />
        )}

        {screen === "settings" && (
          <SettingsTab settings={settings} setSettings={setSettings} services={services} setServices={setServices}
            customers={customers} appointments={appointments}
            onBack={() => goMain("today")} showToast={showToast} onRestore={restoreBackup} />
        )}

        {!phoneCaptureOpen && (
          <button onClick={() => setPhoneCaptureOpen(true)}
            className="fixed bottom-6 left-5 z-40 w-14 h-14 rounded-full flex items-center justify-center transition-transform active:scale-90"
            style={{ background: "var(--accent)", color: "#2A2115", boxShadow: "0 10px 24px -8px rgba(184,134,59,.65)" }} title="ثبت سریع تماس تلفنی">
            <PhoneCall size={22} />
          </button>
        )}

        {phoneCaptureOpen && (
          <PhoneQuickCaptureModal
            customers={customers} services={services} weekHours={settings.weekHours} appointments={appointments}
            initialPhone={sharedPhone}
            onClose={() => { setPhoneCaptureOpen(false); setSharedPhone(""); }}
            onSaved={({ appt, newCustomer }) => {
              setCustomers((p) => [...p, newCustomer]);
              setAppointments((p) => [...p, appt]);
              setPhoneCaptureOpen(false);
              setSharedPhone("");
              showToast("نوبت تلفنی ثبت شد");
            }} />
        )}

        {toast && (
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 fade-in px-5 py-3 rounded-2xl flex items-center gap-2" style={{ background: "var(--ink)", color: "#fff", boxShadow: "0 14px 32px -10px rgba(0,0,0,.45)" }}>
            <Check size={17} /> <span className="text-sm">{toast}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function Header({ shopName, onLogo, onSettings }) {
  const now = useLiveClock();
  const { jd, monthName, weekday } = jalaliLabel(now);
  return (
    <div className="flex items-center justify-between px-6 py-4">
      <button onClick={onLogo} className="flex items-center gap-3 transition-transform active:scale-[0.97]">
        <div className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0"
          style={{ background: "linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%)", boxShadow: "0 3px 10px rgba(28,43,57,0.28)", border: "1px solid rgba(184,134,59,0.35)" }}>
          <Scissors size={19} color="var(--accent-light)" strokeWidth={2.25} />
        </div>
        <div className="text-right">
          <div className="font-extrabold text-[15px] leading-tight tracking-tight" style={{ color: "var(--primary)" }}>{shopName || "پیرایش مردانه"}</div>
          <div className="flex items-center gap-1.5 mt-1">
            <span className="w-3.5 h-px" style={{ background: "var(--accent)" }} />
            <span className="text-[10px] font-semibold tracking-wide" style={{ color: "var(--accent)" }}>پنل آرایشگر</span>
          </div>
        </div>
      </button>
      <div className="flex items-center gap-2">
        <div className="flex flex-col items-end leading-tight px-3 py-1.5 rounded-xl"
          style={{ background: "var(--surface)", border: "1px solid var(--border)", boxShadow: "0 2px 8px -4px rgba(28,43,57,.2)" }}>
          <span className="text-[11px] font-semibold" style={{ color: "var(--primary)" }}>{weekday} {toFa(jd)} {monthName}</span>
          <span className="text-[11px] tabular-nums" dir="ltr" style={{ color: "var(--accent)" }}>{fmtClock(now)}</span>
        </div>
        <button onClick={onSettings} className="p-2.5 rounded-full transition-transform active:scale-90"
          style={{ background: "var(--surface)", border: "1px solid var(--border)", boxShadow: "0 2px 8px -4px rgba(28,43,57,.2)" }}>
          <SettingsIcon size={16} style={{ color: "var(--primary)" }} />
        </button>
      </div>
    </div>
  );
}

function TabBar({ tab, setTab }) {
  const tabs = [
    { key: "today", label: "امروز", icon: Calendar },
    { key: "income", label: "درآمد", icon: Wallet },
    { key: "customers", label: "مشتریان", icon: User },
    { key: "loyal", label: "وفاداران", icon: Star },
    { key: "cycle", label: "موعد اصلاح", icon: Clock },
    { key: "followup", label: "پیگیری", icon: MessageCircle },
  ];
  return (
    <div className="flex gap-2 px-6 pt-4 pb-1 overflow-x-auto no-scrollbar">
      {tabs.map((t) => (
        <button key={t.key} onClick={() => setTab(t.key)}
          className="px-4 py-2 rounded-full text-sm font-medium flex items-center gap-1.5 whitespace-nowrap transition-all duration-200 active:scale-95"
          style={tab === t.key
            ? { background: "var(--primary)", color: "#fff", boxShadow: "0 6px 14px -6px rgba(28,43,57,.55)" }
            : { background: "var(--surface)", color: "var(--muted)", border: "1px solid var(--border)" }}>
          <t.icon size={15} /> {t.label}
        </button>
      ))}
    </div>
  );
}

function BackBar({ title, onBack }) {
  return (
    <div className="flex items-center gap-2 px-6 pt-4 pb-2">
      <button onClick={onBack} className="p-2 rounded-full transition-transform active:scale-90" style={{ background: "var(--surface)", border: "1px solid var(--border)", boxShadow: "0 2px 8px -4px rgba(28,43,57,.2)" }}>
        <ArrowRight size={16} />
      </button>
      <span className="font-bold">{title}</span>
    </div>
  );
}

function DayPicker({ days, selected, onSelect }) {
  return (
    <div className="flex gap-2 overflow-x-auto no-scrollbar pb-3">
      {days.map((d) => {
        const ds = toDateStr(d);
        const { jd, monthName, weekdayShort } = jalaliLabel(d);
        const active = ds === selected;
        return (
          <button key={ds} onClick={() => onSelect(ds)}
            className="flex flex-col items-center justify-center rounded-2xl px-3 py-2 min-w-[62px] border transition-all duration-150 active:scale-95"
            style={active ? { background: "var(--primary)", color: "#fff", borderColor: "var(--primary)", boxShadow: "0 8px 18px -8px rgba(28,43,57,.5)" } : { background: "var(--surface)", borderColor: "var(--border)" }}>
            <span className="text-[11px]">{weekdayShort}</span>
            <span className="font-bold text-lg leading-tight">{toFa(jd)}</span>
            <span className="text-[10px]" style={{ opacity: .8 }}>{monthName}</span>
          </button>
        );
      })}
    </div>
  );
}

function useNext14Days() {
  return useMemo(() => {
    const arr = [];
    for (let i = 0; i < 14; i++) { const d = new Date(); d.setDate(d.getDate() + i); arr.push(d); }
    return arr;
  }, []);
}

function usePast14Days() {
  return useMemo(() => {
    const arr = [];
    for (let i = 13; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); arr.push(d); }
    return arr;
  }, []);
}

// ساعت زنده؛ همیشه از ساعت و تاریخ خود گوشی/سیستم می‌خونه و هر ثانیه به‌روز می‌شه
function useLiveClock(intervalMs = 1000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}
function fmtClock(d) { return toFa(`${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`); }
function fmtHM(d) { return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`; }

// ---------------- TODAY ----------------
function TodayTab({ appointments, customers, services, weekHours, setAppointments, setCustomers, showToast, onOpenCustomer, onEditAppt }) {
  const liveNow = useLiveClock(30000); // هر ۳۰ ثانیه با ساعت گوشی هماهنگ می‌شه تا اگه برنامه بعد از نیمه‌شب باز بمونه هم "امروز" درست باشه
  const days = useNext14Days();
  const today = toDateStr(liveNow);
  const [date, setDate] = useState(today);
  const [autoFollow, setAutoFollow] = useState(true); // تا وقتی کاربر خودش روز دیگه‌ای رو انتخاب نکرده، با امروزِ واقعی همراه بمون
  useEffect(() => { if (autoFollow) setDate(today); }, [today, autoFollow]);
  const selectDay = (d) => { setDate(d); setAutoFollow(d === toDateStr(new Date())); };
  const [confirmCancelId, setConfirmCancelId] = useState(null);
  const [walkinOpen, setWalkinOpen] = useState(false);
  const [nextVisitAppt, setNextVisitAppt] = useState(null); // نوبتی که تازه اصلاحش تموم شده و می‌خوایم نوبت بعدیش رو بپرسیم

  const list = appointments.filter((a) => a.date === date).sort((a, b) => timeToMinutes(a.time) - timeToMinutes(b.time));
  const isPastDay = date < today;

  const cancel = (id) => { setAppointments((p) => p.filter((a) => a.id !== id)); setConfirmCancelId(null); showToast("نوبت لغو شد"); };
  const markDone = (id) => {
    setAppointments((p) => p.map((a) => (a.id === id ? { ...a, status: "done", doneAt: toDateStr(new Date()) } : a)));
    showToast("اصلاح ثبت شد");
    const appt = appointments.find((a) => a.id === id);
    if (appt) setNextVisitAppt(appt);
  };
  const undoDone = (id) => {
    setAppointments((p) => p.map((a) => (a.id === id ? { ...a, status: undefined, doneAt: undefined } : a)));
  };

  const dailyTotal = list.filter((a) => isCompletedAppt(a, today) || a.status === "done").reduce((s, a) => s + priceOfAppt(a, services), 0);

  return (
    <div className="px-6 pt-4 pb-16 fade-in">
      <div className="flex items-center justify-between mb-1">
        <DayPicker days={days} selected={date} onSelect={selectDay} />
      </div>
      <div className="flex items-center justify-between mb-3">
        <div className="text-xs flex items-center gap-1.5" style={{ color: "var(--muted)" }}>
          <span>{toFa(list.length)} نوبت{dailyTotal > 0 ? ` · جمع ${formatToman(dailyTotal)} ت` : ""}</span>
          {date === today && (
            <span className="inline-flex items-center gap-1 text-[10px]" style={{ color: "var(--accent)" }}>
              {" "}· <span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--accent)" }} /> اکنون {toFa(fmtHM(liveNow))}
            </span>
          )}
        </div>
        <button onClick={() => setWalkinOpen(true)} className="btn-gold px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5">
          <Zap size={13} /> ثبت سریع حضوری
        </button>
      </div>

      {list.length === 0 ? (
        <div className="text-center py-16 card">
          <Calendar size={28} className="mx-auto mb-3" style={{ color: "var(--muted)" }} />
          <p style={{ color: "var(--muted)" }}>برای این روز نوبتی ثبت نشده</p>
        </div>
      ) : (
        <div className="space-y-3">
          {list.map((a) => {
            const c = customers.find((x) => x.id === a.customerId);
            const sv = services.find((s) => s.id === a.serviceId);
            const confirming = confirmCancelId === a.id;
            return (
              <div key={a.id} className="card p-4">
                <div className="flex items-center justify-between">
                  <button onClick={() => onOpenCustomer(a.customerId)} className="flex items-center gap-4 text-right flex-1">
                    <div className="font-extrabold min-w-[54px]" style={{ color: "var(--primary)" }}>{minutesToLabel(timeToMinutes(a.time))}</div>
                    <div className="w-px h-9" style={{ background: "var(--border)" }} />
                    <div>
                      <div className="font-semibold flex items-center gap-1.5">
                        {c?.name || "مشتری حذف‌شده"}
                        {c && isPendingName(c.name) && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: "var(--accent)", color: "#2A2115" }}>تکمیل نشده</span>
                        )}
                      </div>
                      <div className="text-xs mt-0.5" style={{ color: "var(--muted)" }}>{sv?.name} · {formatToman(priceOfAppt(a, services))} ت{c?.phone ? ` · ${toFa(c.phone)}` : ""}</div>
                    </div>
                  </button>
                  <div className="flex items-center gap-1">
                    {a.status === "done" ? (
                      <button onClick={() => undoDone(a.id)} className="px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1" style={{ background: "var(--accent-light)", color: "var(--primary)" }}>
                        <Check size={14} /> اصلاح شد
                      </button>
                    ) : (
                      <button onClick={() => markDone(a.id)} className="p-2 rounded-full transition-transform active:scale-90" style={{ background: "var(--bg)", color: "var(--accent)" }} title="ثبت اصلاح انجام‌شده"><Check size={17} /></button>
                    )}
                    {!isPastDay && a.status !== "done" && (
                      <button onClick={() => onEditAppt(a.id)} className="p-2 rounded-full transition-transform active:scale-90" style={{ background: "var(--bg)", color: "var(--primary)" }} title="جابه‌جایی نوبت"><CalendarClock size={17} /></button>
                    )}
                    {c?.phone && (
                      <a href={`tel:${c.phone}`} className="p-2 rounded-full transition-transform active:scale-90" style={{ background: "var(--bg)", color: "var(--primary)" }}><PhoneCall size={17} /></a>
                    )}
                    <button onClick={() => setConfirmCancelId(confirming ? null : a.id)} className="p-2 rounded-full transition-transform active:scale-90" style={{ background: "var(--bg)", color: "#B23A3A" }}><Trash2 size={17} /></button>
                  </div>
                </div>
                {confirming && (
                  <div className="flex items-center justify-end gap-3 mt-3 pt-3" style={{ borderTop: "1px solid var(--border)" }}>
                    <span className="text-xs" style={{ color: "var(--muted)" }}>این نوبت لغو بشه؟</span>
                    <button onClick={() => cancel(a.id)} className="text-xs font-semibold" style={{ color: "#B23A3A" }}>بله، لغو کن</button>
                    <button onClick={() => setConfirmCancelId(null)} className="text-xs" style={{ color: "var(--muted)" }}>انصراف</button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {walkinOpen && (
        <WalkinModal customers={customers} services={services}
          onClose={() => setWalkinOpen(false)}
          onSaved={({ appt, newCustomer }) => {
            if (newCustomer) setCustomers((p) => [...p, newCustomer]);
            setAppointments((p) => [...p, appt]);
            setWalkinOpen(false);
            showToast("اصلاح حضوری ثبت شد");
          }} />
      )}

      {nextVisitAppt && (
        <NextVisitModal
          appt={nextVisitAppt} customers={customers} services={services} weekHours={weekHours} appointments={appointments}
          onClose={() => setNextVisitAppt(null)}
          onScheduled={(newAppt, replaceId) => {
            setAppointments((p) => (replaceId ? p.map((a) => (a.id === replaceId ? newAppt : a)) : [...p, newAppt]));
            setNextVisitAppt(null);
            showToast(replaceId ? "نوبت بعدی جابه‌جا شد" : "نوبت بعدی ثبت شد");
          }} />
      )}
    </div>
  );
}

// مشتری‌ای که سرزده اومده و همون لحظه کارش انجام شده؛ بدون رفتن توی مسیر کامل نوبت‌دهی ثبت می‌شه
// وقتی اصلاح یک مشتری الان تموم شد، ازت می‌پرسه که نوبت بعدیش رو (مثلاً ۵ روز دیگه که خودش گفته) همین الان رزرو کنیم یا نه؛
// این دقیق‌تر از پیش‌بینی آماری دوره‌ی اصلاحه، چون بر اساس چیزیه که مشتری خودش موقع رفتن گفته.
function NextVisitModal({ appt, customers, services, weekHours, appointments, onClose, onScheduled }) {
  const liveNow = useLiveClock(1000);
  const today = toDateStr(liveNow);
  const customer = customers.find((c) => c.id === appt.customerId);
  const service = services.find((s) => s.id === appt.serviceId);
  const [showCustomDate, setShowCustomDate] = useState(false);
  const [pickerDate, setPickerDate] = useState(() => addDays(today, 7));
  const days = useNext14Days();

  // اگه این مشتری از قبل یک نوبت آینده‌ی باز داره، به‌جای اضافه کردن یک نوبت تکراری،
  // پیش‌فرض اینه که همون نوبت رو جابه‌جا کنیم؛ ولی اگه واقعاً بخوان جدا اضافه کنن هم می‌شه.
  const existingUpcoming = useMemo(() => upcomingApptsOf(appt.customerId, appointments, today, appt.id), [appt.customerId, appt.id, appointments, today]);
  const hasExisting = existingUpcoming.length > 0;
  const [mode, setMode] = useState("reschedule"); // reschedule | separate

  const preferredTime = timeToMinutes(appt.time);

  const scheduleIn = (n) => {
    if (!service) return;
    const target = addDays(today, n);
    const slot = findSlotOnOrAfter({ date: target, service, services, weekHours, appointments, now: liveNow, preferredTime });
    if (!slot) return;
    finalize(slot);
  };

  const finalize = (slot) => {
    const timeStr = `${String(Math.floor(slot.time / 60)).padStart(2, "0")}:${String(slot.time % 60).padStart(2, "0")}`;
    if (hasExisting && mode === "reschedule") {
      const target = existingUpcoming[0];
      onScheduled({ ...target, date: slot.date, time: timeStr, serviceId: appt.serviceId, price: service?.price ?? target.price }, target.id);
    } else {
      onScheduled({ id: uid(), customerId: appt.customerId, serviceId: appt.serviceId, date: slot.date, price: service?.price || 0, time: timeStr }, null);
    }
  };

  const pickerSlots = useMemo(() => {
    if (!service) return [];
    return computeDaySlots({ date: pickerDate, service, services, weekHours, appointments, now: liveNow });
  }, [pickerDate, service, services, weekHours, appointments, liveNow]);

  if (!customer || !service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <div className="card w-full max-w-md p-5 fade-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-1">
          <div className="font-semibold text-sm flex items-center gap-1.5">
            <CalendarClock size={15} style={{ color: "var(--accent)" }} /> نوبت بعدی {customer.name}
          </div>
          <button onClick={onClose}><X size={18} style={{ color: "var(--muted)" }} /></button>
        </div>
        <p className="text-xs mb-3" style={{ color: "var(--muted)" }}>اگه گفته چند روز دیگه میاد، همین الان براش رزرو کن تا فراموش نشه.</p>

        {hasExisting && (
          <div className="rounded-xl p-3 mb-3" style={{ background: "var(--accent-light)" }}>
            <div className="flex items-center gap-1.5 text-xs font-semibold mb-1" style={{ color: "var(--primary)" }}>
              <AlertCircle size={13} />
              {existingUpcoming.length > 1 ? `این مشتری الان ${toFa(existingUpcoming.length)} نوبت آینده داره` : "این مشتری الان یک نوبت آینده داره"}
            </div>
            <div className="text-[11px] mb-2.5" style={{ color: "var(--primary)", opacity: .8 }}>
              {(() => {
                const { jd, monthName, weekday } = jalaliLabel(parseLocalDate(existingUpcoming[0].date));
                return `نزدیک‌ترینش: ${weekday}، ${toFa(jd)} ${monthName} — ساعت ${minutesToLabel(timeToMinutes(existingUpcoming[0].time))}`;
              })()}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setMode("reschedule")}
                className="flex-1 py-1.5 rounded-lg text-[11px] font-semibold"
                style={mode === "reschedule" ? { background: "var(--primary)", color: "#fff" } : { background: "var(--surface)", color: "var(--primary)" }}>
                جابه‌جا کردن همین نوبت
              </button>
              <button onClick={() => setMode("separate")}
                className="flex-1 py-1.5 rounded-lg text-[11px] font-semibold"
                style={mode === "separate" ? { background: "var(--primary)", color: "#fff" } : { background: "var(--surface)", color: "var(--primary)" }}>
                نوبت جدا اضافه کن
              </button>
            </div>
          </div>
        )}

        {!showCustomDate ? (
          <>
            <div className="grid grid-cols-4 gap-2 mb-3">
              {[5, 7, 10, 14].map((n) => (
                <button key={n} onClick={() => scheduleIn(n)}
                  className="py-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-0.5"
                  style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
                  <span className="text-base font-extrabold" style={{ color: "var(--primary)" }}>{toFa(n)}</span>
                  <span style={{ color: "var(--muted)" }}>روز دیگه</span>
                </button>
              ))}
            </div>
            <button onClick={() => setShowCustomDate(true)}
              className="w-full py-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 mb-2"
              style={{ borderColor: "var(--border)", color: "var(--primary)" }}>
              <Calendar size={14} /> انتخاب تاریخ دیگه
            </button>
          </>
        ) : (
          <div className="mb-3 fade-in">
            <DayPicker days={days} selected={pickerDate} onSelect={setPickerDate} />
            {pickerSlots.length === 0 ? (
              <div className="text-center py-6 card mt-2"><p className="text-xs" style={{ color: "var(--muted)" }}>برای این روز وقت خالی نیست</p></div>
            ) : (
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 mt-2">
                {pickerSlots.map((t) => (
                  <button key={t} onClick={() => finalize({ date: pickerDate, time: t })}
                    className="slot-btn py-2 rounded-xl border text-xs font-medium"
                    style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
                    {minutesToLabel(t)}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <button onClick={onClose} className="w-full py-2.5 rounded-xl text-xs font-semibold" style={{ color: "var(--muted)" }}>
          فعلاً نه، بعداً تعیین می‌کنم
        </button>
      </div>
    </div>
  );
}


// مشتری‌ای که سرزده اومده و همون لحظه کارش انجام شده؛ بدون رفتن توی مسیر کامل نوبت‌دهی ثبت می‌شه
function WalkinModal({ customers, services, onClose, onSaved }) {
  const liveNow = useLiveClock(1000); // مستقیم از ساعت زنده‌ی گوشی/سیستم می‌خونه
  const [mode, setMode] = useState("existing"); // existing | new
  const [q, setQ] = useState("");
  const [pickedId, setPickedId] = useState(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [serviceId, setServiceId] = useState(services[0]?.id || "");
  const [price, setPrice] = useState(services[0]?.price || 0);
  const [time, setTime] = useState(fmtHM(liveNow)); // ساعت پیش‌فرض = همین الان، ولی قابل ویرایشه
  const [timeTouched, setTimeTouched] = useState(false);

  const service = services.find((s) => s.id === serviceId);
  const filtered = q.trim() ? customers.filter((c) => c.name.includes(q) || c.phone.includes(q)).slice(0, 6) : [];

  useEffect(() => { setPrice(service?.price || 0); }, [serviceId]);
  // تا وقتی کاربر خودش ساعت رو دستی عوض نکرده، فیلد ساعت با ساعت زنده جلو میره
  useEffect(() => { if (!timeTouched) setTime(fmtHM(liveNow)); }, [liveNow, timeTouched]);

  const { jd, monthName, weekday } = jalaliLabel(liveNow);
  const canSave = (mode === "existing" ? !!pickedId : name.trim().length > 0) && /^\d{2}:\d{2}$/.test(time);

  const save = () => {
    if (!canSave) return;
    const todayStr = toDateStr(liveNow);
    let customerId = pickedId;
    let newCustomer = null;
    if (mode === "new") {
      newCustomer = { id: uid(), name: name.trim(), phone: phone.trim(), hairstyle: "", notes: "", createdAt: todayStr, hasPhoto: false, styleHistory: [] };
      customerId = newCustomer.id;
    }
    const appt = { id: uid(), customerId, serviceId, date: todayStr, price: Number(price) || 0, time, status: "done", doneAt: todayStr };
    onSaved({ appt, newCustomer });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <div className="card w-full max-w-md p-5 fade-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <div className="font-semibold text-sm flex items-center gap-1.5"><Zap size={15} style={{ color: "var(--accent)" }} /> ثبت سریع اصلاح حضوری</div>
          <button onClick={onClose}><X size={18} style={{ color: "var(--muted)" }} /></button>
        </div>

        <div className="flex items-center justify-between rounded-xl px-3 py-2.5 mb-3" style={{ background: "var(--accent-light)" }}>
          <div className="flex items-center gap-1.5 text-xs font-semibold" style={{ color: "var(--primary)" }}>
            <Calendar size={13} /> امروز، {weekday} {toFa(jd)} {monthName}
          </div>
          <div className="flex items-center gap-1.5">
            <div className="flex items-center gap-1 text-xs font-semibold tabular-nums" style={{ color: "var(--accent)" }} dir="ltr">
              <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "var(--accent)" }} />
              {fmtClock(liveNow)}
            </div>
          </div>
        </div>

        <div className="mb-3">
          <div className="text-xs mb-1.5" style={{ color: "var(--muted)" }}>ساعت ثبت (پیش‌فرض: همین الان)</div>
          <div className="flex items-center gap-2">
            <input type="time" value={time} onChange={(e) => { setTime(e.target.value); setTimeTouched(true); }} dir="ltr"
              className="flex-1 px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
            {timeTouched && (
              <button onClick={() => { setTimeTouched(false); setTime(fmtHM(liveNow)); }}
                className="px-3 py-2.5 rounded-xl text-xs font-semibold border whitespace-nowrap" style={{ borderColor: "var(--border)", color: "var(--primary)" }}>
                الان
              </button>
            )}
          </div>
        </div>

        <div className="flex gap-2 mb-3">
          <button onClick={() => setMode("existing")} className="flex-1 py-2 rounded-xl text-xs font-semibold"
            style={mode === "existing" ? { background: "var(--primary)", color: "#fff" } : { background: "var(--bg)", color: "var(--muted)", border: "1px solid var(--border)" }}>مشتری قبلی</button>
          <button onClick={() => setMode("new")} className="flex-1 py-2 rounded-xl text-xs font-semibold"
            style={mode === "new" ? { background: "var(--primary)", color: "#fff" } : { background: "var(--bg)", color: "var(--muted)", border: "1px solid var(--border)" }}>مشتری جدید</button>
        </div>

        {mode === "existing" ? (
          <div className="mb-3">
            <div className="relative">
              <Search size={16} className="absolute top-1/2 -translate-y-1/2 right-3" style={{ color: "var(--muted)" }} />
              <input value={q} onChange={(e) => { setQ(e.target.value); setPickedId(null); }} placeholder="جستجوی نام یا شماره..."
                className="w-full pr-10 pl-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
            </div>
            {filtered.length > 0 && (
              <div className="mt-2 space-y-1.5 max-h-40 overflow-y-auto">
                {filtered.map((c) => (
                  <button key={c.id} onClick={() => { setPickedId(c.id); setQ(c.name); }}
                    className="w-full text-right px-3 py-2 rounded-xl text-sm flex items-center justify-between"
                    style={pickedId === c.id ? { background: "var(--accent-light)" } : { background: "var(--bg)" }}>
                    <span>{c.name}</span><span className="text-[11px]" style={{ color: "var(--muted)" }} dir="ltr">{toFa(c.phone)}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2.5 mb-3">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="نام مشتری"
              className="w-full px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
            <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="شماره تلفن (اختیاری)" dir="ltr"
              className="w-full px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
          </div>
        )}

        <div className="mb-3">
          <div className="text-xs mb-1.5" style={{ color: "var(--muted)" }}>نوع کار</div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {services.map((s) => (
              <button key={s.id} onClick={() => setServiceId(s.id)}
                className="px-3 py-1.5 rounded-xl border text-xs whitespace-nowrap"
                style={serviceId === s.id ? { background: "var(--primary)", color: "#fff", borderColor: "var(--primary)" } : { background: "var(--surface)", borderColor: "var(--border)" }}>
                {s.name}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-4">
          <div className="text-xs mb-1.5" style={{ color: "var(--muted)" }}>مبلغ (تومان)</div>
          <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} dir="ltr"
            className="w-full px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
        </div>

        <button onClick={save} disabled={!canSave} className="btn-primary w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2">
          <Check size={16} /> ثبت اصلاح انجام‌شده
        </button>
      </div>
    </div>
  );
}

// ---------------- ثبت سریع تماس تلفنی ----------------
// برای وقتی که آرایشگر دستش بند اصلاح یکی دیگه‌س و پشت تلفن باید نوبت بگیره؛
// حداقل تایپ لازمه: یک اسم پیش‌فرض غیرتکراری از قبل انتخاب‌شده تو فیلده و نزدیک‌ترین وقت خالی خودش پیشنهاد می‌شه.
function PhoneQuickCaptureModal({ customers, services, weekHours, appointments, onClose, onSaved, initialPhone }) {
  const liveNow = useLiveClock(1000);
  const [pendingName] = useState(() => generatePendingName(customers));
  const [name, setName] = useState(pendingName);
  const [phone, setPhone] = useState(initialPhone || "");
  const [phoneAuto, setPhoneAuto] = useState(!!initialPhone); // آیا شماره خودکار (اشتراک‌گذاری/کلیپ‌بورد) پر شده؟
  const [serviceId, setServiceId] = useState(services[0]?.id || "");
  const [showTimePicker, setShowTimePicker] = useState(false);
  const days = useNext14Days();
  const nameRef = useRef(null);

  useEffect(() => { nameRef.current?.select(); }, []);

  // اگه شماره از قبل (با اشتراک‌گذاری از لیست تماس‌ها) نیومده، سعی می‌کنیم خودمون از کلیپ‌بورد بخونیم؛
  // مثلاً وقتی آرایشگر شماره رو تو صفحه‌ی تماس گوشی کپی کرده بوده.
  useEffect(() => {
    if (initialPhone) return;
    (async () => {
      try {
        if (!navigator.clipboard || !navigator.clipboard.readText) return;
        const text = await navigator.clipboard.readText();
        const num = extractPhoneNumber(text);
        if (num) { setPhone(num); setPhoneAuto(true); }
      } catch (e) { /* اجازه‌ی خواندن کلیپ‌بورد داده نشد؛ دکمه‌ی دستی هست */ }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      const num = extractPhoneNumber(text);
      if (num) { setPhone(num); setPhoneAuto(true); }
    } catch (e) { /* روی بعضی گوشی‌ها نیاز به اجازه‌ی دستی داره */ }
  };

  const service = services.find((s) => s.id === serviceId);

  const [slot, setSlot] = useState(null); // { date, time } | null
  useEffect(() => {
    const suggestion = findNextAvailableSlot({ service, services, weekHours, appointments, now: liveNow });
    setSlot(suggestion);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serviceId]);

  const [pickerDate, setPickerDate] = useState(() => slot?.date || toDateStr(liveNow));
  useEffect(() => { if (slot) setPickerDate(slot.date); }, [slot]);
  const pickerSlots = useMemo(() => {
    if (!service) return [];
    return computeDaySlots({ date: pickerDate, service, services, weekHours, appointments, now: liveNow });
  }, [pickerDate, service, services, weekHours, appointments, liveNow]);

  const canSave = name.trim().length > 0 && !!slot;

  const save = () => {
    if (!canSave) return;
    const finalName = name.trim() || pendingName;
    const newCustomer = { id: uid(), name: finalName, phone: phone.trim(), hairstyle: "", notes: "", createdAt: toDateStr(liveNow), hasPhoto: false, styleHistory: [] };
    const timeStr = `${String(Math.floor(slot.time / 60)).padStart(2, "0")}:${String(slot.time % 60).padStart(2, "0")}`;
    const appt = { id: uid(), customerId: newCustomer.id, serviceId, date: slot.date, price: service?.price || 0, time: timeStr };
    onSaved({ appt, newCustomer });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <div className="card w-full max-w-md p-5 fade-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <div className="font-semibold text-sm flex items-center gap-1.5">
            <PhoneCall size={15} style={{ color: "var(--accent)" }} /> ثبت سریع تماس تلفنی
          </div>
          <button onClick={onClose}><X size={18} style={{ color: "var(--muted)" }} /></button>
        </div>

        <div className="mb-3">
          <div className="text-xs mb-1.5" style={{ color: "var(--muted)" }}>نام مشتری (یک اسم پیش‌فرض انتخاب شده؛ اگه وقت داری بنویس، وگرنه بعداً اصلاحش کن)</div>
          <input ref={nameRef} value={name} onChange={(e) => setName(e.target.value)} onFocus={(e) => e.target.select()}
            className="w-full px-3 py-3 rounded-xl border text-sm font-semibold" style={{ borderColor: "var(--border)" }} />
        </div>

        <div className="mb-3">
          <div className="flex items-center gap-2">
            <input value={phone} onChange={(e) => { setPhone(e.target.value); setPhoneAuto(false); }}
              placeholder="شماره تلفن (اختیاری، بعداً هم می‌شه اضافه کرد)" dir="ltr"
              className="flex-1 px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
            <button type="button" onClick={pasteFromClipboard} title="چسباندن شماره از کلیپ‌بورد"
              className="shrink-0 w-10 h-10 rounded-xl border flex items-center justify-center"
              style={{ borderColor: "var(--border)", color: "var(--primary)" }}>
              <Clipboard size={16} />
            </button>
          </div>
          {phoneAuto && phone && (
            <div className="text-[11px] mt-1 flex items-center gap-1" style={{ color: "var(--accent)" }}>
              <ClipboardCheck size={12} /> شماره خودکار پر شد؛ اگه درست نیست ویرایشش کن
            </div>
          )}
        </div>

        <div className="mb-3">
          <div className="text-xs mb-1.5" style={{ color: "var(--muted)" }}>نوع کار</div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {services.map((s) => (
              <button key={s.id} onClick={() => setServiceId(s.id)}
                className="px-3 py-1.5 rounded-xl border text-xs whitespace-nowrap"
                style={serviceId === s.id ? { background: "var(--primary)", color: "#fff", borderColor: "var(--primary)" } : { background: "var(--surface)", borderColor: "var(--border)" }}>
                {s.name}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-xl p-3 mb-2" style={{ background: "var(--accent-light)" }}>
          <div className="text-[11px] mb-1" style={{ color: "var(--primary)", opacity: .75 }}>نزدیک‌ترین وقت خالی (پیشنهاد خودکار)</div>
          {slot ? (
            <div className="flex items-center justify-between">
              <div className="font-bold text-sm" style={{ color: "var(--primary)" }}>
                {(() => { const { jd, monthName, weekday } = jalaliLabel(parseLocalDate(slot.date)); const isToday = slot.date === toDateStr(liveNow);
                  return `${isToday ? "امروز" : weekday}، ${toFa(jd)} ${monthName} — ساعت ${minutesToLabel(slot.time)}`; })()}
              </div>
              <button onClick={() => setShowTimePicker((v) => !v)} className="text-xs font-semibold px-2.5 py-1.5 rounded-lg" style={{ background: "var(--surface)", color: "var(--primary)" }}>
                {showTimePicker ? "بستن" : "تغییر"}
              </button>
            </div>
          ) : (
            <p className="text-xs" style={{ color: "var(--primary)" }}>تا ۱۴ روز آینده وقت خالی برای این خدمت پیدا نشد.</p>
          )}
        </div>

        {showTimePicker && (
          <div className="mb-3 fade-in">
            <DayPicker days={days} selected={pickerDate} onSelect={setPickerDate} />
            {pickerSlots.length === 0 ? (
              <div className="text-center py-6 card mt-2"><p className="text-xs" style={{ color: "var(--muted)" }}>برای این روز وقت خالی نیست</p></div>
            ) : (
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 mt-2">
                {pickerSlots.map((t) => (
                  <button key={t} onClick={() => { setSlot({ date: pickerDate, time: t }); setShowTimePicker(false); }}
                    className="slot-btn py-2 rounded-xl border text-xs font-medium"
                    style={slot?.date === pickerDate && slot?.time === t ? { background: "var(--primary)", color: "#fff", borderColor: "var(--primary)" } : { background: "var(--surface)", borderColor: "var(--border)" }}>
                    {minutesToLabel(t)}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <button onClick={save} disabled={!canSave} className="btn-primary w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 mt-1">
          <Check size={16} /> ثبت نوبت
        </button>
      </div>
    </div>
  );
}


function IncomeTab({ appointments, customers, services }) {
  const today = toDateStr(new Date());
  const days = usePast14Days();
  const [date, setDate] = useState(today);

  const completedOn = useCallback(
    (d) => appointments.filter((a) => isCompletedAppt(a, today) && cutDateOf(a) === d),
    [appointments, today]
  );

  const dayTotal = (d) => completedOn(d).reduce((sum, a) => sum + priceOfAppt(a, services), 0);

  const selectedList = useMemo(
    () => completedOn(date).slice().sort((a, b) => timeToMinutes(a.time) - timeToMinutes(b.time)),
    [completedOn, date]
  );
  const selectedTotal = selectedList.reduce((s, a) => s + priceOfAppt(a, services), 0);
  const todayTotal = dayTotal(today);
  const todayCount = completedOn(today).length;

  // میانگین درآمد به تفکیک روز هفته، برای پیدا کردن روزهای ضعیف
  const weekdayStats = useMemo(() => {
    const stats = Array.from({ length: 7 }, () => ({ total: 0, count: 0, days: new Set() }));
    appointments.forEach((a) => {
      if (!isCompletedAppt(a, today)) return;
      const d = cutDateOf(a);
      const wd = parseLocalDate(d).getDay();
      stats[wd].total += priceOfAppt(a, services);
      stats[wd].count += 1;
      stats[wd].days.add(d);
    });
    return stats.map((s, i) => ({
      idx: i,
      weekday: WEEKDAYS[i],
      weekdayShort: WEEKDAYS_SHORT[i],
      total: s.total,
      count: s.count,
      daysCount: s.days.size,
      avg: s.days.size ? s.total / s.days.size : 0,
    }));
  }, [appointments, today, services]);

  const activeDays = weekdayStats.filter((w) => w.daysCount > 0);
  const maxAvg = Math.max(1, ...weekdayStats.map((w) => w.avg));
  const overallAvg = activeDays.length ? activeDays.reduce((s, w) => s + w.avg, 0) / activeDays.length : 0;
  const weakest = activeDays.length >= 2 ? activeDays.slice().sort((a, b) => a.avg - b.avg)[0] : null;
  const strongest = activeDays.length >= 2 ? activeDays.slice().sort((a, b) => b.avg - a.avg)[0] : null;

  return (
    <div className="px-6 pt-4 pb-16 fade-in">
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="card p-4">
          <div className="text-xs" style={{ color: "var(--muted)" }}>سود امروز</div>
          <div className="font-extrabold text-lg mt-1" style={{ color: "var(--primary)" }}>{formatToman(todayTotal)} <span className="text-xs font-normal">تومان</span></div>
        </div>
        <div className="card p-4">
          <div className="text-xs" style={{ color: "var(--muted)" }}>تعداد مشتری امروز</div>
          <div className="font-extrabold text-lg mt-1" style={{ color: "var(--primary)" }}>{toFa(todayCount)} نفر</div>
        </div>
      </div>

      {weakest && strongest && weakest.idx !== strongest.idx && (
        <div className="card p-4 mb-4 flex items-start gap-2.5">
          <TrendingDown size={18} className="flex-shrink-0 mt-0.5" style={{ color: "#B23A3A" }} />
          <div className="text-xs leading-6">
            <span className="font-semibold">{weakest.weekday}‌ها</span> معمولاً ضعیف‌ترین روزت هستن (میانگین {formatToman(weakest.avg)} ت)،
            در مقابل <span className="font-semibold">{strongest.weekday}‌ها</span> پرسودترین روزن (میانگین {formatToman(strongest.avg)} ت).
          </div>
        </div>
      )}

      <div className="card p-4 mb-4">
        <div className="text-xs mb-3" style={{ color: "var(--muted)" }}>میانگین درآمد به تفکیک روز هفته</div>
        <div className="space-y-2.5">
          {weekdayStats.map((w) => (
            <div key={w.idx} className="flex items-center gap-3">
              <span className="text-xs w-12 flex-shrink-0">{w.weekdayShort}</span>
              <div className="flex-1 h-2.5 rounded-full overflow-hidden" style={{ background: "var(--bg)" }}>
                <div className="h-full rounded-full" style={{
                  width: `${w.daysCount ? Math.max(4, (w.avg / maxAvg) * 100) : 0}%`,
                  background: w.daysCount === 0 ? "var(--border)" : (weakest && w.idx === weakest.idx ? "#B23A3A" : "var(--accent)"),
                }} />
              </div>
              <span className="text-[11px] w-20 text-left flex-shrink-0" style={{ color: "var(--muted)" }} dir="ltr">
                {w.daysCount ? formatToman(w.avg) : "—"}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>مشاهده سود یک روز خاص</div>
      <DayPicker days={days} selected={date} onSelect={setDate} />

      {selectedList.length === 0 ? (
        <div className="text-center py-14 card mt-3">
          <Wallet size={26} className="mx-auto mb-3" style={{ color: "var(--muted)" }} />
          <p style={{ color: "var(--muted)" }}>برای این روز اصلاحی ثبت نشده</p>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between px-1 mt-3 mb-2">
            <span className="text-xs" style={{ color: "var(--muted)" }}>جمع این روز</span>
            <span className="font-bold text-sm" style={{ color: "var(--primary)" }}>{formatToman(selectedTotal)} تومان</span>
          </div>
          <div className="space-y-2">
            {selectedList.map((a) => {
              const c = customers.find((x) => x.id === a.customerId);
              const sv = services.find((s) => s.id === a.serviceId);
              return (
                <div key={a.id} className="card p-3 flex items-center justify-between text-sm">
                  <div>
                    <div className="font-medium">{c?.name || "مشتری حذف‌شده"}</div>
                    <div className="text-[11px]" style={{ color: "var(--muted)" }}>{sv?.name} · {minutesToLabel(timeToMinutes(a.time))}</div>
                  </div>
                  <span className="font-semibold" style={{ color: "var(--accent)" }}>{formatToman(priceOfAppt(a, services))} ت</span>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

// ---------------- CUSTOMERS ----------------
function CustomersTab({ customers, appointments, onAddNew, onOpenCustomer, onBook }) {
  const [q, setQ] = useState("");
  const filtered = customers.filter((c) => c.name.includes(q) || c.phone.includes(q))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  const lastVisit = (id) => {
    const past = appointments.filter((a) => a.customerId === id && a.date <= toDateStr(new Date())).sort((a, b) => b.date.localeCompare(a.date));
    return past[0]?.date || null;
  };

  return (
    <div className="px-6 pt-4 pb-16 fade-in">
      <button onClick={onAddNew} className="btn-primary w-full py-3.5 rounded-2xl text-sm font-semibold flex items-center justify-center gap-2 mb-4">
        <Plus size={17} /> ثبت مشتری جدید
      </button>

      <div className="relative mb-4">
        <Search size={16} className="absolute top-1/2 -translate-y-1/2 right-3" style={{ color: "var(--muted)" }} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی نام یا شماره..."
          className="w-full pr-10 pl-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-14 card">
          <User size={26} className="mx-auto mb-3" style={{ color: "var(--muted)" }} />
          <p style={{ color: "var(--muted)" }}>{customers.length === 0 ? "هنوز مشتری‌ای ثبت نشده" : "چیزی پیدا نشد"}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((c) => {
            const lv = lastVisit(c.id);
            const cycleDays = estimateCycleDays(c.id, appointments, toDateStr(new Date()));
            return (
              <div key={c.id} className="card p-4 flex items-center justify-between">
                <button onClick={() => onOpenCustomer(c.id)} className="flex items-center gap-3 text-right flex-1">
                  <Avatar customer={c} cycleDays={cycleDays} />
                  <div>
                    <div className="font-semibold flex items-center gap-1.5">
                      {c.name}
                      {isPendingName(c.name) && (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: "var(--accent)", color: "#2A2115" }}>تکمیل نشده</span>
                      )}
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: "var(--muted)" }} dir="ltr">{toFa(c.phone)}</div>
                    <div className="text-[11px] mt-0.5" style={{ color: "var(--muted)" }}>
                      {lv ? `آخرین حضور: ${toFa(daysBetween(lv, toDateStr(new Date())))} روز پیش` : "هنوز نیومده"}
                    </div>
                  </div>
                </button>
                <button onClick={() => onBook(c.id)} className="btn-gold px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 whitespace-nowrap">
                  <Calendar size={14} /> تعیین وقت
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Avatar({ customer, cycleDays, size = 44 }) {
  const [photo, setPhoto] = useState(null);
  useEffect(() => {
    if (!customer.hasPhoto) return;
    window.storage.get(K_PHOTO(customer.id), false).then((r) => r?.value && setPhoto(r.value)).catch(() => {});
  }, [customer.id, customer.hasPhoto]);
  const px = `${size}px`;
  return (
    <div className="relative flex-shrink-0" style={{ width: px, height: px }}>
      {photo ? (
        <img src={photo} alt="" className="w-full h-full rounded-full object-cover border" style={{ borderColor: "var(--border)" }} />
      ) : (
        <div className="w-full h-full rounded-full flex items-center justify-center font-bold" style={{ background: "var(--accent-light)", color: "var(--primary)", fontSize: size * 0.4 }}>
          {customer.name.trim()[0] || "?"}
        </div>
      )}
      {cycleDays != null && (
        <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-1.5 py-[1px] rounded-full text-[9px] font-bold whitespace-nowrap"
          style={{ background: "var(--primary)", color: "#fff", border: "1.5px solid var(--surface)" }} title="بر اساس فاصله اصلاح‌های قبلی محاسبه شده">
          هر {toFa(cycleDays)} روز
        </div>
      )}
    </div>
  );
}

// ---------------- NEW CUSTOMER ----------------
function NewCustomerFlow({ onCancel, onSaved, showToast }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [hairstyle, setHairstyle] = useState("");
  const [notes, setNotes] = useState("");
  const [isFixed, setIsFixed] = useState(false);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [photoError, setPhotoError] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef(null);

  const pickPhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoError(false);
    try {
      const dataUrl = await resizeImageFile(file);
      setPhotoPreview(dataUrl);
    } catch (err) {
      setPhotoError(true);
    } finally {
      e.target.value = "";
    }
  };

  const save = async () => {
    if (!name.trim() || !phone.trim() || saving) return;
    setSaving(true);
    const newId = uid();
    let photoSaved = true;
    if (photoPreview) {
      const r = await window.storage.set(K_PHOTO(newId), photoPreview, false).catch(() => null);
      photoSaved = !!r;
    }
    const customer = { id: newId, name: name.trim(), phone: phone.trim(), hairstyle: hairstyle.trim(), notes: notes.trim(), isFixed, createdAt: toDateStr(new Date()), hasPhoto: !!photoPreview && photoSaved, styleHistory: [] };
    onSaved(customer);
    if (photoPreview && !photoSaved) showToast?.("مشتری ذخیره شد ولی عکس ذخیره نشد؛ دوباره امتحان کن");
  };

  return (
    <div className="px-6 pt-2 pb-16 fade-in">
      <BackBar title="ثبت مشتری جدید" onBack={onCancel} />

      <div className="card p-5 space-y-4 mt-2">
        <div className="flex justify-center">
          <button onClick={() => fileRef.current?.click()} className="relative w-20 h-20 rounded-full flex items-center justify-center border-2 border-dashed" style={{ borderColor: "var(--border)" }}>
            {photoPreview ? (
              <img src={photoPreview} alt="" className="w-full h-full rounded-full object-cover" />
            ) : (
              <Camera size={22} style={{ color: "var(--muted)" }} />
            )}
          </button>
          <input ref={fileRef} type="file" accept="image/*" onChange={pickPhoto} className="hidden" />
        </div>
        <p className="text-center text-[11px] -mt-2" style={{ color: "var(--muted)" }}>عکس مدل مو یا چهره مشتری (اختیاری)</p>
        {photoError && <p className="text-center text-[11px] -mt-1" style={{ color: "#B23A3A" }}>این فایل قابل خوندن نبود؛ یک عکس دیگه انتخاب کن</p>}

        <div>
          <label className="text-xs" style={{ color: "var(--muted)" }}>نام و نام خانوادگی</label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً علی رضایی"
            className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1" style={{ borderColor: "var(--border)" }} />
        </div>
        <div>
          <label className="text-xs" style={{ color: "var(--muted)" }}>شماره تلفن</label>
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="09xxxxxxxxx" dir="ltr"
            className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1" style={{ borderColor: "var(--border)" }} />
        </div>
        <div>
          <label className="text-xs" style={{ color: "var(--muted)" }}>مدل موی موردنظر</label>
          <input value={hairstyle} onChange={(e) => setHairstyle(e.target.value)} placeholder="مثلاً فید کوتاه، ریش خطی..."
            className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1" style={{ borderColor: "var(--border)" }} />
        </div>
        <div>
          <label className="text-xs" style={{ color: "var(--muted)" }}>یادداشت (سلیقه، کارهای قبلی، حساسیت و...)</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} placeholder="مثلاً دفعه قبل شماره ۲ زده شد، پوست سرش حساسه..."
            className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1 resize-none" style={{ borderColor: "var(--border)" }} />
        </div>

        <button type="button" onClick={() => setIsFixed((v) => !v)}
          className="w-full flex items-center justify-between px-3.5 py-3 rounded-xl border"
          style={isFixed ? { background: "var(--accent-light)", borderColor: "var(--accent)" } : { borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2">
            <Star size={16} style={{ color: isFixed ? "#8A5A00" : "var(--muted)" }} />
            <div className="text-right">
              <div className="text-sm font-semibold">مشتری ثابت / وفادار</div>
              <div className="text-[11px]" style={{ color: "var(--muted)" }}>مستقیم توی لیست «وفاداران» نشون داده می‌شه</div>
            </div>
          </div>
          <div className="w-10 h-6 rounded-full flex-shrink-0 relative transition-colors" style={{ background: isFixed ? "var(--accent)" : "var(--border)" }}>
            <div className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all" style={isFixed ? { left: "0.125rem" } : { right: "0.125rem" }} />
          </div>
        </button>

        <button onClick={save} disabled={!name.trim() || !phone.trim() || saving}
          className="btn-primary w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2">
          <Calendar size={16} /> ذخیره و تعیین وقت
        </button>
      </div>
    </div>
  );
}

// ---------------- BOOKING ----------------
function BookingFlow({ customer, services, weekHours, appointments, onCancel, onConfirm, editingAppt }) {
  const days = useNext14Days();
  const [date, setDate] = useState(editingAppt?.date || toDateStr(new Date()));
  const [serviceId, setServiceId] = useState(editingAppt?.serviceId || services[0].id);
  const [time, setTime] = useState(editingAppt ? timeToMinutes(editingAppt.time) : null);
  const [price, setPrice] = useState(editingAppt ? priceOfAppt(editingAppt, services) : (services[0].price || 0));

  const service = services.find((s) => s.id === serviceId);
  const dayCfg = weekHours?.[parseLocalDate(date).getDay()] || { closed: false, start: "10:00", end: "21:00" };

  const slots = useMemo(() => {
    if (!service || dayCfg.closed) return [];
    const now = new Date();
    const result = computeDaySlots({ date, service, services, weekHours, appointments, excludeApptId: editingAppt?.id, now });
    // اگر داریم نوبت را جابه‌جا می‌کنیم، ساعت فعلی‌اش هم به‌عنوان گزینه در دسترس باشه
    if (editingAppt && date === editingAppt.date) {
      const curT = timeToMinutes(editingAppt.time);
      if (!result.includes(curT)) result.push(curT);
      result.sort((a, b) => a - b);
    }
    return result;
  }, [service, date, dayCfg, appointments, editingAppt, services, weekHours]);

  useEffect(() => { if (!editingAppt || date !== editingAppt.date) setTime(null); }, [date, serviceId]);
  useEffect(() => { if (!editingAppt) setPrice(service?.price || 0); }, [serviceId]);

  const confirm = () => {
    if (time === null) return;
    const timeStr = `${String(Math.floor(time / 60)).padStart(2, "0")}:${String(time % 60).padStart(2, "0")}`;
    if (editingAppt) {
      onConfirm({ ...editingAppt, serviceId, date, price: Number(price) || 0, time: timeStr });
    } else {
      onConfirm({ id: uid(), customerId: customer.id, serviceId, date, price: Number(price) || 0, time: timeStr });
    }
  };

  return (
    <div className="px-6 pt-2 pb-24 fade-in">
      <BackBar title={editingAppt ? `جابه‌جایی نوبت ${customer.name}` : `تعیین وقت برای ${customer.name}`} onBack={onCancel} />

      <div className="mb-4">
        <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>نوع کار</div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {services.map((s) => (
            <button key={s.id} onClick={() => setServiceId(s.id)}
              className="px-3.5 py-2 rounded-xl border text-sm whitespace-nowrap"
              style={serviceId === s.id ? { background: "var(--primary)", color: "#fff", borderColor: "var(--primary)" } : { background: "var(--surface)", borderColor: "var(--border)" }}>
              {s.name} <span className="opacity-70">({toFa(s.duration)} د)</span>
            </button>
          ))}
        </div>
      </div>

      <div className="mb-4">
        <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>مبلغ (تومان)</div>
        <div className="relative">
          <Wallet size={16} className="absolute top-1/2 -translate-y-1/2 right-3" style={{ color: "var(--muted)" }} />
          <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} dir="ltr"
            className="w-full pr-10 pl-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
        </div>
      </div>

      <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>تاریخ</div>
      <DayPicker days={days} selected={date} onSelect={setDate} />

      <div className="text-xs mt-3 mb-2" style={{ color: "var(--muted)" }}>ساعت‌های خالی (پیشنهاد خودکار)</div>
      {dayCfg.closed ? (
        <div className="text-center py-10 card">
          <Lock size={20} className="mx-auto mb-2" style={{ color: "var(--muted)" }} />
          <p style={{ color: "var(--muted)" }}>این روز طبق تنظیمات آرایشگاه تعطیله</p>
        </div>
      ) : slots.length === 0 ? (
        <div className="text-center py-10 card"><p style={{ color: "var(--muted)" }}>برای این روز وقت خالی نیست</p></div>
      ) : (
        <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
          {slots.map((t) => (
            <button key={t} onClick={() => setTime(t)} className="slot-btn py-2.5 rounded-xl border text-sm font-medium"
              style={time === t ? { background: "var(--primary)", color: "#fff", borderColor: "var(--primary)" } : { background: "var(--surface)", borderColor: "var(--border)" }}>
              {minutesToLabel(t)}
            </button>
          ))}
        </div>
      )}

      <button onClick={confirm} disabled={time === null}
        className="btn-primary w-full py-3.5 rounded-2xl text-sm font-semibold mt-6 flex items-center justify-center gap-2">
        <Check size={17} /> {editingAppt ? "ثبت جابه‌جایی" : "ثبت نهایی وقت"}
      </button>
    </div>
  );
}

// ---------------- CUSTOMER DETAIL ----------------
function CustomerDetail({ customer, appointments, services, onBack, onSave, onDelete, onBook, onEditAppt, showToast }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(customer.name);
  const [phone, setPhone] = useState(customer.phone);
  const [hairstyle, setHairstyle] = useState(customer.hairstyle || "");
  const [notes, setNotes] = useState(customer.notes || "");
  const [isFixed, setIsFixed] = useState(!!customer.isFixed);
  const [photo, setPhoto] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const fileRef = useRef(null);
  const today = toDateStr(new Date());

  useEffect(() => {
    if (!customer.hasPhoto) return;
    window.storage.get(K_PHOTO(customer.id), false).then((r) => r?.value && setPhoto(r.value)).catch(() => {});
  }, [customer.id, customer.hasPhoto]);

  const history = appointments.filter((a) => a.customerId === customer.id).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  const visitCount = appointments.filter((a) => a.customerId === customer.id && isCompletedAppt(a, today)).length;

  const lastCut = lastCutInfo(customer.id, appointments, today);
  const cycleDays = estimateCycleDays(customer.id, appointments, today);
  const nextDue = lastCut && cycleDays != null ? addDays(lastCut, cycleDays) : null;
  const dueDiff = nextDue ? daysBetween(today, nextDue) : null;
  const upcoming = upcomingApptsOf(customer.id, appointments, today);

  const pickPhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await resizeImageFile(file);
      const r = await window.storage.set(K_PHOTO(customer.id), dataUrl, false).catch(() => null);
      if (!r) { showToast("عکس ذخیره نشد؛ دوباره امتحان کن"); return; }
      setPhoto(dataUrl);
      onSave({ ...customer, hasPhoto: true });
    } catch (err) {
      showToast("این فایل قابل خوندن نبود");
    } finally {
      e.target.value = "";
    }
  };

  const save = () => {
    onSave({ ...customer, name: name.trim(), phone: phone.trim(), hairstyle: hairstyle.trim(), notes: notes.trim(), isFixed });
    setEditing(false);
    showToast("تغییرات ذخیره شد");
  };

  return (
    <div className="px-6 pt-2 pb-16 fade-in">
      <BackBar title="پرونده مشتری" onBack={onBack} />

      <div className="card p-5">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => editing && fileRef.current?.click()} className="relative flex-shrink-0">
            <div className="w-16 h-16 rounded-full overflow-hidden flex items-center justify-center" style={{ background: "var(--accent-light)", boxShadow: "0 4px 14px -4px rgba(28,43,57,.3)", border: "2px solid var(--surface)" }}>
              {photo ? <img src={photo} alt="" className="w-full h-full object-cover" /> : <span className="font-bold text-xl" style={{ color: "var(--primary)" }}>{customer.name.trim()[0]}</span>}
            </div>
            {cycleDays != null && (
              <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap"
                style={{ background: "var(--primary)", color: "#fff", border: "2px solid var(--surface)" }}>
                هر {toFa(cycleDays)} روز
              </div>
            )}
          </button>
          <input ref={fileRef} type="file" accept="image/*" onChange={pickPhoto} className="hidden" />
          <div className="flex-1">
            {editing ? (
              <input value={name} onChange={(e) => setName(e.target.value)} className="w-full px-3 py-2 rounded-xl border text-sm font-semibold" style={{ borderColor: "var(--border)" }} />
            ) : (
              <div className="font-bold text-lg flex items-center gap-1.5">
                {customer.name}
                {customer.isFixed && <Star size={14} style={{ color: "#8A5A00" }} />}
              </div>
            )}
            <div className="flex items-center gap-2 mt-1">
              {editing ? (
                <input value={phone} onChange={(e) => setPhone(e.target.value)} dir="ltr" className="px-3 py-1.5 rounded-lg border text-xs flex-1" style={{ borderColor: "var(--border)" }} />
              ) : (
                <a href={`tel:${customer.phone}`} className="text-xs flex items-center gap-1" style={{ color: "var(--muted)" }} dir="ltr"><PhoneCall size={12} />{toFa(customer.phone)}</a>
              )}
            </div>
          </div>
          {!editing && (
            <button onClick={() => setEditing(true)} className="p-2 rounded-full" style={{ background: "var(--bg)" }}><Edit3 size={16} /></button>
          )}
        </div>

        {upcoming.length > 0 && (
          <div className="rounded-2xl p-3.5 mb-3" style={{ background: "var(--accent-light)" }}>
            <div className="flex items-center gap-1.5 text-xs font-semibold mb-1.5" style={{ color: "var(--primary)" }}>
              <CalendarClock size={13} /> نوبت بعدی (رزرو‌شده)
              {upcoming.length > 1 && (
                <span className="mr-auto text-[10px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: "#B23A3A", color: "#fff" }}>
                  {toFa(upcoming.length)} نوبت باز
                </span>
              )}
            </div>
            {upcoming.map((a) => {
              const sv = services.find((s) => s.id === a.serviceId);
              const { jd, monthName, weekday } = jalaliLabel(parseLocalDate(a.date));
              return (
                <div key={a.id} className="flex items-center justify-between text-sm mt-1">
                  <span style={{ color: "var(--primary)" }}>{weekday}، {toFa(jd)} {monthName} · {minutesToLabel(timeToMinutes(a.time))}</span>
                  <span className="text-[11px]" style={{ color: "var(--primary)", opacity: .75 }}>{sv?.name}</span>
                </div>
              );
            })}
            {upcoming.length > 1 && (
              <div className="text-[10px] mt-1.5" style={{ color: "var(--primary)", opacity: .7 }}>
                این مشتری چند نوبت آینده‌ی باز داره؛ بهتره یکیشون رو لغو یا جابه‌جا کنی.
              </div>
            )}
          </div>
        )}

        <div className="rounded-2xl p-3.5 mb-4" style={{ background: "var(--bg)" }}>
          <div className="flex items-center justify-between text-sm">
            <span style={{ color: "var(--muted)" }}>آخرین اصلاح</span>
            <span className="font-semibold">
              {lastCut ? `${toFa(daysBetween(lastCut, today))} روز پیش` : "هنوز اصلاح نشده"}
            </span>
          </div>
          {lastCut && cycleDays != null && (
            <div className="flex items-center justify-between text-sm mt-1.5">
              <span style={{ color: "var(--muted)" }}>موعد بعدی</span>
              <span className="font-semibold" style={{ color: dueDiff < 0 ? "#B23A3A" : dueDiff === 0 ? "var(--accent)" : "var(--primary)" }}>
                {dueDiff < 0 ? `${toFa(Math.abs(dueDiff))} روز از موعدش گذشته` : dueDiff === 0 ? "امروز موعدشه" : `${toFa(dueDiff)} روز دیگر`}
              </span>
            </div>
          )}
          <div className="flex items-center justify-between text-sm mt-2.5">
            <span style={{ color: "var(--muted)" }}>دوره اصلاح</span>
            <span className="font-semibold" title="بر اساس فاصله بین اصلاح‌های واقعی این مشتری محاسبه شده، نه یک عدد ثابت">
              {cycleDays != null
                ? `هر ${toFa(cycleDays)} روز`
                : visitCount === 1
                  ? "بعد از بار بعدی مشخص می‌شه"
                  : "هنوز اصلاحی ثبت نشده"}
            </span>
          </div>
        </div>

        <div className="mb-3">
          <label className="text-xs" style={{ color: "var(--muted)" }}>مدل موی موردنظر</label>
          {editing ? (
            <input value={hairstyle} onChange={(e) => setHairstyle(e.target.value)} className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1" style={{ borderColor: "var(--border)" }} />
          ) : (
            <div className="text-sm mt-1">{customer.hairstyle || "—"}</div>
          )}
        </div>

        <div className="mb-2">
          <label className="text-xs" style={{ color: "var(--muted)" }}>یادداشت</label>
          {editing ? (
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1 resize-none" style={{ borderColor: "var(--border)" }} />
          ) : (
            <div className="text-sm mt-1" style={{ color: customer.notes ? "var(--ink)" : "var(--muted)" }}>{customer.notes || "یادداشتی ثبت نشده"}</div>
          )}
        </div>

        {editing && (
          <button type="button" onClick={() => setIsFixed((v) => !v)}
            className="w-full flex items-center justify-between px-3.5 py-3 rounded-xl border mt-1 mb-1"
            style={isFixed ? { background: "var(--accent-light)", borderColor: "var(--accent)" } : { borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Star size={16} style={{ color: isFixed ? "#8A5A00" : "var(--muted)" }} />
              <div className="text-right">
                <div className="text-sm font-semibold">مشتری ثابت / وفادار</div>
                <div className="text-[11px]" style={{ color: "var(--muted)" }}>مستقیم توی لیست «وفاداران» نشون داده می‌شه</div>
              </div>
            </div>
            <div className="w-10 h-6 rounded-full flex-shrink-0 relative transition-colors" style={{ background: isFixed ? "var(--accent)" : "var(--border)" }}>
              <div className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all" style={isFixed ? { left: "0.125rem" } : { right: "0.125rem" }} />
            </div>
          </button>
        )}

        {editing && (
          <div className="flex gap-2 mt-4">
            <button onClick={save} className="btn-primary flex-1 py-2.5 rounded-xl text-sm font-semibold">ذخیره</button>
            <button onClick={() => setEditing(false)} className="flex-1 py-2.5 rounded-xl text-sm font-semibold border" style={{ borderColor: "var(--border)" }}>انصراف</button>
          </div>
        )}
      </div>

      <button onClick={onBook} className="btn-gold w-full py-3 rounded-2xl text-sm font-semibold flex items-center justify-center gap-2 mt-4">
        <Calendar size={16} /> تعیین وقت جدید
      </button>

      <StyleHistorySection customer={customer} onSave={onSave} showToast={showToast} />

      <div className="mt-6">
        <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>سابقه نوبت‌ها</div>
        {history.length === 0 ? (
          <div className="text-sm py-4 text-center" style={{ color: "var(--muted)" }}>هنوز نوبتی ثبت نشده</div>
        ) : (
          <div className="space-y-2">
            {history.map((a) => {
              const sv = services.find((s) => s.id === a.serviceId);
              const { jd, monthName } = jalaliLabel(parseLocalDate(a.date));
              const upcoming = a.date >= today && a.status !== "done" && a.status !== "canceled";
              return (
                <div key={a.id} className="card p-3 flex items-center justify-between text-sm">
                  <span>{sv?.name}{isCompletedAppt(a, toDateStr(new Date())) ? ` · ${formatToman(priceOfAppt(a, services))} ت` : ""}</span>
                  <div className="flex items-center gap-2">
                    <span style={{ color: "var(--muted)" }}>{toFa(jd)} {monthName} · {minutesToLabel(timeToMinutes(a.time))}</span>
                    {upcoming && onEditAppt && (
                      <button onClick={() => onEditAppt(a.id)} className="p-1.5 rounded-full" style={{ color: "var(--primary)" }} title="جابه‌جایی نوبت"><CalendarClock size={14} /></button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="mt-8 text-center">
        {!confirmDelete ? (
          <button onClick={() => setConfirmDelete(true)} className="text-xs" style={{ color: "#B23A3A" }}>حذف مشتری</button>
        ) : (
          <div className="flex items-center justify-center gap-3">
            <span className="text-xs" style={{ color: "var(--muted)" }}>مطمئنی؟</span>
            <button onClick={() => onDelete(customer.id)} className="text-xs font-semibold" style={{ color: "#B23A3A" }}>بله، حذف کن</button>
            <button onClick={() => setConfirmDelete(false)} className="text-xs" style={{ color: "var(--muted)" }}>انصراف</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------------- آرشیو مدل‌های مو (شبیه گرید پروفایل اینستاگرام) ----------------
// هر مشتری می‌تونه چند «مدل مو» ثبت‌شده داشته باشه، هرکدوم با عکس، اسم مدل، تاریخ و یادداشت.
// این جدا از «مدل موی موردنظر» (customer.hairstyle) هست؛ اون یک خط برای مدلی که مشتری می‌خواد،
// این‌جا یک آرشیو کامل از مدل‌هایی که واقعاً تا حالا زده.
function StyleHistorySection({ customer, onSave, showToast }) {
  const history = customer.styleHistory || [];
  const sorted = useMemo(() => [...history].sort((a, b) => (b.date || "").localeCompare(a.date || "") || (b.createdAt || "").localeCompare(a.createdAt || "")), [history]);
  const [viewing, setViewing] = useState(null);
  const [adding, setAdding] = useState(false);

  const addEntry = (entry) => {
    onSave({ ...customer, styleHistory: [...(customer.styleHistory || []), entry] });
    setAdding(false);
    showToast("مدل جدید به آرشیو اضافه شد");
  };

  const deleteEntry = async (entry) => {
    if (entry.hasPhoto) await window.storage.delete(K_STYLE_PHOTO(customer.id, entry.id)).catch(() => {});
    onSave({ ...customer, styleHistory: (customer.styleHistory || []).filter((e) => e.id !== entry.id) });
    setViewing(null);
    showToast("از آرشیو حذف شد");
  };

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between mb-2">
        <div className="text-xs flex items-center gap-1.5" style={{ color: "var(--muted)" }}>
          <ImagePlus size={13} /> آرشیو مدل‌های مو {sorted.length > 0 && `(${toFa(sorted.length)})`}
        </div>
        <button onClick={() => setAdding(true)} className="text-xs font-semibold flex items-center gap-1" style={{ color: "var(--primary)" }}>
          <Plus size={13} /> افزودن مدل
        </button>
      </div>

      {sorted.length === 0 ? (
        <button onClick={() => setAdding(true)} className="w-full py-8 rounded-2xl flex flex-col items-center gap-1.5 text-xs"
          style={{ border: "1px dashed var(--border)", color: "var(--muted)" }}>
          <Camera size={20} />
          هنوز مدلی ثبت نشده؛ اولین عکس رو اضافه کن
        </button>
      ) : (
        <div className="grid grid-cols-3 gap-1.5">
          {sorted.map((entry) => (
            <StyleThumb key={entry.id} entry={entry} customerId={customer.id} onClick={() => setViewing(entry)} />
          ))}
        </div>
      )}

      {adding && <AddStyleEntryModal customer={customer} onClose={() => setAdding(false)} onSave={addEntry} showToast={showToast} />}
      {viewing && (
        <ViewStyleEntryModal entry={viewing} customerId={customer.id} onClose={() => setViewing(null)} onDelete={() => deleteEntry(viewing)} />
      )}
    </div>
  );
}

function StyleThumb({ entry, customerId, onClick }) {
  const [photo, setPhoto] = useState(null);
  useEffect(() => {
    if (!entry.hasPhoto) return;
    window.storage.get(K_STYLE_PHOTO(customerId, entry.id), false).then((r) => r?.value && setPhoto(r.value)).catch(() => {});
  }, [customerId, entry.id, entry.hasPhoto]);

  const { jd, monthName } = jalaliLabel(parseLocalDate(entry.date));

  return (
    <button onClick={onClick} className="relative aspect-square rounded-xl overflow-hidden" style={{ background: "var(--bg)" }}>
      {photo ? (
        <img src={photo} alt="" className="w-full h-full object-cover" />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center gap-1 p-1.5 text-center" style={{ background: "var(--accent-light)" }}>
          <Scissors size={16} style={{ color: "var(--primary)" }} />
          <span className="text-[9px] leading-tight" style={{ color: "var(--primary)" }}>{entry.title || "بدون عکس"}</span>
        </div>
      )}
      <div className="absolute bottom-0 inset-x-0 px-1 py-1 text-[9px] text-white text-center"
        style={{ background: "linear-gradient(to top, rgba(0,0,0,.6), transparent)" }}>
        {toFa(jd)} {monthName}
      </div>
    </button>
  );
}

function AddStyleEntryModal({ customer, onClose, onSave, showToast }) {
  const [photoPreview, setPhotoPreview] = useState(null);
  const [title, setTitle] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(toDateStr(new Date()));
  const [saving, setSaving] = useState(false);
  const fileRef = useRef(null);

  const [photoError, setPhotoError] = useState(false);
  const pickPhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoError(false);
    try {
      const dataUrl = await resizeImageFile(file);
      setPhotoPreview(dataUrl);
    } catch (err) {
      setPhotoError(true);
    } finally {
      e.target.value = "";
    }
  };

  const canSave = !!(title.trim() || photoPreview);

  const save = async () => {
    if (!canSave || saving) return;
    setSaving(true);
    const entryId = uid();
    let photoSaved = true;
    if (photoPreview) {
      const r = await window.storage.set(K_STYLE_PHOTO(customer.id, entryId), photoPreview, false).catch(() => null);
      photoSaved = !!r;
    }
    onSave({ id: entryId, date, title: title.trim(), note: note.trim(), hasPhoto: !!photoPreview && photoSaved, createdAt: new Date().toISOString() });
    if (photoPreview && !photoSaved) showToast?.("مدل ذخیره شد ولی عکسش ذخیره نشد؛ دوباره امتحان کن");
  };

  const dateLabel = (() => { try { const { jd, monthName, weekday } = jalaliLabel(parseLocalDate(date)); return `${weekday}، ${toFa(jd)} ${monthName}`; } catch (e) { return ""; } })();

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: "rgba(0,0,0,.5)" }} onClick={onClose}>
      <div className="w-full max-w-md rounded-t-3xl p-5 fade-in max-h-[90vh] overflow-y-auto" style={{ background: "var(--surface)" }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div className="font-bold text-sm">افزودن مدل جدید</div>
          <button onClick={onClose}><X size={18} /></button>
        </div>

        <button onClick={() => fileRef.current?.click()} className="w-full aspect-square max-h-48 rounded-2xl overflow-hidden flex flex-col items-center justify-center gap-2 mb-3"
          style={{ background: "var(--bg)", border: "1px dashed var(--border)" }}>
          {photoPreview ? (
            <img src={photoPreview} alt="" className="w-full h-full object-cover" />
          ) : (
            <>
              <ImagePlus size={22} style={{ color: "var(--muted)" }} />
              <span className="text-xs" style={{ color: "var(--muted)" }}>افزودن عکس (اختیاری)</span>
            </>
          )}
        </button>
        <input ref={fileRef} type="file" accept="image/*" capture="environment" onChange={pickPhoto} className="hidden" />
        {photoError && <p className="text-center text-[11px] -mt-1.5 mb-2" style={{ color: "#B23A3A" }}>این فایل قابل خوندن نبود؛ یک عکس دیگه انتخاب کن</p>}

        <label className="text-xs" style={{ color: "var(--muted)" }}>اسم مدل</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً فید کوتاه، تاپ فرم..."
          className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1 mb-3" style={{ borderColor: "var(--border)" }} />

        <label className="text-xs" style={{ color: "var(--muted)" }}>تاریخ</label>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} dir="ltr"
          className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1" style={{ borderColor: "var(--border)" }} />
        {dateLabel && <div className="text-[11px] mt-1 mb-3" style={{ color: "var(--muted)" }}>{dateLabel}</div>}

        <label className="text-xs" style={{ color: "var(--muted)" }}>یادداشت (اختیاری)</label>
        <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2}
          className="w-full px-3 py-2.5 rounded-xl border text-sm mt-1 mb-4 resize-none" style={{ borderColor: "var(--border)" }} />

        <button onClick={save} disabled={!canSave || saving} className="btn-primary w-full py-3 rounded-xl text-sm font-semibold">
          {saving ? "در حال ذخیره..." : "ذخیره در آرشیو"}
        </button>
      </div>
    </div>
  );
}

function ViewStyleEntryModal({ entry, customerId, onClose, onDelete }) {
  const [photo, setPhoto] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  useEffect(() => {
    if (!entry.hasPhoto) return;
    window.storage.get(K_STYLE_PHOTO(customerId, entry.id), false).then((r) => r?.value && setPhoto(r.value)).catch(() => {});
  }, [customerId, entry.id, entry.hasPhoto]);

  const { jd, monthName, weekday } = jalaliLabel(parseLocalDate(entry.date));

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: "rgba(0,0,0,.6)" }} onClick={onClose}>
      <div className="w-full max-w-md rounded-t-3xl overflow-hidden fade-in max-h-[90vh] overflow-y-auto" style={{ background: "var(--surface)" }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 pt-4 pb-2">
          <div className="font-bold text-sm">{entry.title || "بدون اسم"}</div>
          <button onClick={onClose}><X size={18} /></button>
        </div>
        {photo && (
          <div className="w-full aspect-square" style={{ background: "var(--bg)" }}>
            <img src={photo} alt="" className="w-full h-full object-cover" />
          </div>
        )}
        <div className="px-5 py-4">
          <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>{weekday}، {toFa(jd)} {monthName}</div>
          {entry.note && <div className="text-sm mb-3">{entry.note}</div>}
          {!confirmDelete ? (
            <button onClick={() => setConfirmDelete(true)} className="text-xs flex items-center gap-1" style={{ color: "#B23A3A" }}>
              <Trash2 size={13} /> حذف از آرشیو
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <span className="text-xs" style={{ color: "var(--muted)" }}>مطمئنی؟</span>
              <button onClick={onDelete} className="text-xs font-semibold" style={{ color: "#B23A3A" }}>بله، حذف کن</button>
              <button onClick={() => setConfirmDelete(false)} className="text-xs" style={{ color: "var(--muted)" }}>انصراف</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------------- LOYAL CUSTOMERS / مشتریان وفادار ----------------
function tierOf(visits, isFixed) {
  if (isFixed) return { label: "ثابت", color: "#8A5A00", bg: "var(--accent-light)", Icon: Star };
  if (visits >= 10) return { label: "VIP", color: "#8A5A00", bg: "var(--accent-light)", Icon: Crown };
  if (visits >= 5) return { label: "وفادار", color: "var(--primary)", bg: "var(--accent-light)", Icon: Star };
  return { label: "مشتری", color: "var(--muted)", bg: "var(--bg)", Icon: null };
}

function LoyalTab({ customers, appointments, services, onOpenCustomer }) {
  const [q, setQ] = useState("");
  const today = toDateStr(new Date());

  const list = useMemo(() => {
    return customers
      .map((c) => {
        const done = appointments.filter((a) => a.customerId === c.id && isCompletedAppt(a, today));
        if (done.length === 0 && !c.isFixed) return null;
        const totalSpent = done.reduce((s, a) => s + priceOfAppt(a, services), 0);
        const lastCut = lastCutInfo(c.id, appointments, today);
        const cycleDays = estimateCycleDays(c.id, appointments, today);
        return { customer: c, visits: done.length, totalSpent, lastCut, cycleDays };
      })
      .filter(Boolean)
      .filter((x) => x.customer.name.includes(q) || x.customer.phone.includes(q))
      .sort((a, b) => (b.customer.isFixed - a.customer.isFixed) || b.visits - a.visits || b.totalSpent - a.totalSpent);
  }, [customers, appointments, services, q, today]);

  const vipCount = list.filter((x) => x.visits >= 10 && !x.customer.isFixed).length;
  const loyalCount = list.filter((x) => (x.visits >= 5 && x.visits < 10 && !x.customer.isFixed) || x.customer.isFixed).length;

  return (
    <div className="px-6 pt-4 pb-16 fade-in">
      <div className="card p-4 mb-4">
        <div className="flex items-start gap-2 text-xs" style={{ color: "var(--muted)" }}>
          <Star size={15} className="flex-shrink-0 mt-0.5" />
          <span>مثل دفترچه مخاطبین، مشتری‌هایی که بیشتر بهت سر می‌زنن رو بر اساس تعداد اصلاح مرتب می‌کنیم؛ هر مشتری رو هم می‌تونی از پرونده‌ش دستی «ثابت» علامت بزنی تا همیشه اینجا باشه.</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="card p-3.5 flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "var(--accent-light)" }}>
            <Crown size={16} style={{ color: "#8A5A00" }} />
          </div>
          <div>
            <div className="font-bold text-sm">{toFa(vipCount)} نفر</div>
            <div className="text-[11px]" style={{ color: "var(--muted)" }}>مشتری VIP (۱۰+)</div>
          </div>
        </div>
        <div className="card p-3.5 flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "var(--accent-light)" }}>
            <Star size={16} style={{ color: "var(--primary)" }} />
          </div>
          <div>
            <div className="font-bold text-sm">{toFa(loyalCount)} نفر</div>
            <div className="text-[11px]" style={{ color: "var(--muted)" }}>مشتری وفادار (۵-۹)</div>
          </div>
        </div>
      </div>

      <div className="relative mb-4">
        <Search size={16} className="absolute top-1/2 -translate-y-1/2 right-3" style={{ color: "var(--muted)" }} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی نام یا شماره..."
          className="w-full pr-10 pl-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
      </div>

      {list.length === 0 ? (
        <div className="text-center py-14 card">
          <Star size={26} className="mx-auto mb-3" style={{ color: "var(--muted)" }} />
          <p style={{ color: "var(--muted)" }}>هنوز مشتری با سابقه اصلاح ثبت نشده</p>
        </div>
      ) : (
        <div className="space-y-3">
          {list.map(({ customer, visits, totalSpent, lastCut, cycleDays }) => {
            const tier = tierOf(visits, customer.isFixed);
            return (
              <button key={customer.id} onClick={() => onOpenCustomer(customer.id)} className="card p-4 flex items-center justify-between w-full text-right">
                <div className="flex items-center gap-3">
                  <Avatar customer={customer} cycleDays={cycleDays} />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold">{customer.name}</span>
                      {tier.Icon && <tier.Icon size={13} style={{ color: tier.color }} />}
                    </div>
                    <div className="text-[11px] mt-0.5" style={{ color: "var(--muted)" }}>
                      {toFa(visits)} بار اصلاح · {formatToman(totalSpent)} ت
                      {lastCut ? ` · آخرین بار ${toFa(daysBetween(lastCut, today))} روز پیش` : ""}
                    </div>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold flex-shrink-0" style={{ background: tier.bg, color: tier.color }}>
                  {tier.label}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ---------------- HAIRCUT CYCLE (پیش‌بینی موعد اصلاح) ----------------
function CycleTab({ customers, appointments, onOpenCustomer, onBook }) {
  const [windowDays, setWindowDays] = useState(10);
  const today = toDateStr(new Date());

  const list = useMemo(() => {
    return customers.map((c) => {
      const lastCut = lastCutInfo(c.id, appointments, today);
      if (!lastCut) return null;
      const cycleDays = estimateCycleDays(c.id, appointments, today);
      if (cycleDays == null) return null; // دوره‌اش هنوز با یک بار مراجعه مشخص نیست
      const nextDue = addDays(lastCut, cycleDays);
      const dueDiff = daysBetween(today, nextDue);
      if (dueDiff > windowDays) return null;
      const hasUpcoming = appointments.some((a) => a.customerId === c.id && a.date >= today && a.status !== "canceled");
      return { customer: c, lastCut, nextDue, dueDiff, hasUpcoming, cycleDays };
    }).filter(Boolean).sort((a, b) => a.dueDiff - b.dueDiff);
  }, [customers, appointments, windowDays, today]);

  const pendingFirstCycle = useMemo(() => {
    return customers.filter((c) => {
      const doneCount = appointments.filter((a) => a.customerId === c.id && isCompletedAppt(a, today)).length;
      return doneCount === 1;
    });
  }, [customers, appointments, today]);

  return (
    <div className="px-6 pt-4 pb-16 fade-in">
      <div className="card p-4 mb-4">
        <div className="flex items-start gap-2 text-xs" style={{ color: "var(--muted)" }}>
          <Clock size={15} className="flex-shrink-0 mt-0.5" />
          <span>دوره اصلاح هر مشتری خودکار از روی فاصله واقعی اصلاح‌های قبلی‌اش حساب می‌شه؛ بعد از حداقل دو بار مراجعه این‌جا نشونش می‌دیم.</span>
        </div>
        <div className="flex gap-2 mt-3">
          {[3, 7, 10, 15].map((d) => (
            <button key={d} onClick={() => setWindowDays(d)}
              className="px-3.5 py-1.5 rounded-full text-xs font-medium"
              style={windowDays === d ? { background: "var(--primary)", color: "#fff" } : { background: "var(--bg)", color: "var(--muted)", border: "1px solid var(--border)" }}>
              تا {toFa(d)} روز آینده
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <div className="text-center py-14 card">
          <Clock size={26} className="mx-auto mb-3" style={{ color: "var(--muted)" }} />
          <p style={{ color: "var(--muted)" }}>فعلاً کسی تو این بازه موعدش نرسیده</p>
        </div>
      ) : (
        <div className="space-y-3">
          {list.map(({ customer, dueDiff, hasUpcoming, cycleDays }) => (
            <div key={customer.id} className="card p-4 flex items-center justify-between">
              <button onClick={() => onOpenCustomer(customer.id)} className="flex items-center gap-3 text-right flex-1">
                <Avatar customer={customer} cycleDays={cycleDays} />
                <div>
                  <div className="font-semibold">{customer.name}</div>
                  <div className="text-xs mt-0.5 font-medium" style={{ color: dueDiff < 0 ? "#B23A3A" : dueDiff === 0 ? "var(--accent)" : "var(--primary)" }}>
                    {dueDiff < 0 ? `${toFa(Math.abs(dueDiff))} روز از موعدش گذشته` : dueDiff === 0 ? "امروز موعدشه" : `${toFa(dueDiff)} روز تا موعدش`}
                  </div>
                  {hasUpcoming && (
                    <div className="text-[11px] mt-0.5" style={{ color: "var(--muted)" }}>نوبتی براش ثبت شده</div>
                  )}
                </div>
              </button>
              {!hasUpcoming && (
                <button onClick={() => onBook(customer.id)} className="btn-gold px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 whitespace-nowrap">
                  <Calendar size={14} /> تعیین وقت
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {pendingFirstCycle.length > 0 && (
        <div className="mt-6">
          <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>
            این‌ها فقط یک بار اومدن؛ دوره اصلاحشون بعد از بار دوم مشخص می‌شه
          </div>
          <div className="space-y-2">
            {pendingFirstCycle.map((c) => (
              <button key={c.id} onClick={() => onOpenCustomer(c.id)} className="card p-3 flex items-center gap-3 w-full text-right">
                <Avatar customer={c} size={36} />
                <span className="text-sm font-medium">{c.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ---------------- FOLLOW-UP / SMS ----------------
function FollowupTab({ customers, appointments, showToast }) {
  const [threshold, setThreshold] = useState(15);
  const [composeFor, setComposeFor] = useState(null);
  const today = toDateStr(new Date());

  const list = useMemo(() => {
    return customers.map((c) => {
      const hasUpcoming = appointments.some((a) => a.customerId === c.id && a.date >= today);
      if (hasUpcoming) return null;
      const past = appointments.filter((a) => a.customerId === c.id && a.date < today).sort((a, b) => b.date.localeCompare(a.date));
      const refDate = past[0]?.date || c.createdAt;
      const days = daysBetween(refDate, today);
      if (days < threshold) return null;
      return { customer: c, days, everVisited: past.length > 0 };
    }).filter(Boolean).sort((a, b) => b.days - a.days);
  }, [customers, appointments, threshold, today]);

  return (
    <div className="px-6 pt-4 pb-16 fade-in">
      <div className="card p-4 mb-4">
        <div className="flex items-start gap-2 text-xs" style={{ color: "var(--muted)" }}>
          <AlertCircle size={15} className="flex-shrink-0 mt-0.5" />
          <span>مشتری‌هایی که برای مدت زیادی برنگشتن و نوبت آینده‌ای هم ندارن، خودکار اینجا لیست می‌شن.</span>
        </div>
        <div className="flex gap-2 mt-3">
          {[10, 15, 30].map((d) => (
            <button key={d} onClick={() => setThreshold(d)}
              className="px-3.5 py-1.5 rounded-full text-xs font-medium"
              style={threshold === d ? { background: "var(--primary)", color: "#fff" } : { background: "var(--bg)", color: "var(--muted)", border: "1px solid var(--border)" }}>
              بیش از {toFa(d)} روز
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <div className="text-center py-14 card">
          <MessageCircle size={26} className="mx-auto mb-3" style={{ color: "var(--muted)" }} />
          <p style={{ color: "var(--muted)" }}>فعلاً کسی برای پیگیری نیست</p>
        </div>
      ) : (
        <div className="space-y-3">
          {list.map(({ customer, days, everVisited }) => (
            <div key={customer.id} className="card p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar customer={customer} />
                <div>
                  <div className="font-semibold">{customer.name}</div>
                  <div className="text-xs mt-0.5" style={{ color: "#B8863B" }}>
                    {everVisited ? `${toFa(days)} روز از آخرین حضورش می‌گذره` : `${toFa(days)} روزه ثبت شده ولی هنوز نیومده`}
                  </div>
                </div>
              </div>
              <button onClick={() => setComposeFor(customer)} className="btn-gold px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1">
                <MessageCircle size={14} /> پیامک
              </button>
            </div>
          ))}
        </div>
      )}

      {composeFor && (
        <ComposeSmsModal customer={composeFor} onClose={() => setComposeFor(null)} onSent={() => { showToast(`پیامک برای ${composeFor.name} ارسال شد`); setComposeFor(null); }} />
      )}
    </div>
  );
}

// ---------------- SETTINGS ----------------
function downloadJSON(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function SettingsTab({ settings, setSettings, services, setServices, customers, appointments, onBack, showToast, onRestore }) {
  const [shopName, setShopName] = useState(settings.shopName);
  const [addingService, setAddingService] = useState(false);
  const [editingServiceId, setEditingServiceId] = useState(null);
  const fileRef = useRef(null);
  const [confirmRestore, setConfirmRestore] = useState(null);

  const saveShopName = () => {
    if (!shopName.trim()) return;
    setSettings((s) => ({ ...s, shopName: shopName.trim() }));
    showToast("نام آرایشگاه ذخیره شد");
  };

  const setDayCfg = (idx, patch) => {
    setSettings((s) => ({ ...s, weekHours: { ...s.weekHours, [idx]: { ...s.weekHours[idx], ...patch } } }));
  };

  const removeService = (id) => {
    if (services.length <= 1) { showToast("حداقل باید یک خدمت وجود داشته باشه"); return; }
    setServices((p) => p.filter((s) => s.id !== id));
    showToast("خدمت حذف شد");
  };

  const exportBackup = async () => {
    // عکس‌ها (پروفایل مشتری‌ها + آرشیو مدل‌های مو) جدا از بقیه اطلاعات ذخیره می‌شن، پس برای پشتیبان کامل باید همه‌شون رو جمع کنیم
    const photos = {};
    try {
      const profileKeys = (await window.storage.list("barber-photo:", false))?.keys || [];
      const styleKeys = (await window.storage.list("barber-style-photo:", false))?.keys || [];
      for (const k of [...profileKeys, ...styleKeys]) {
        const r = await window.storage.get(k, false).catch(() => null);
        if (r?.value) photos[k] = r.value;
      }
    } catch (e) {}
    downloadJSON(`backup-${toDateStr(new Date())}.json`, { customers, appointments, settings, services, photos, exportedAt: new Date().toISOString() });
    showToast("نسخه پشتیبان دانلود شد (شامل عکس‌ها)");
  };

  const pickRestoreFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        setConfirmRestore(data);
      } catch (err) {
        showToast("فایل معتبر نیست");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  return (
    <div className="px-6 pt-2 pb-16 fade-in">
      <BackBar title="تنظیمات" onBack={onBack} />

      <div className="card p-4 mb-4">
        <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>نام آرایشگاه</div>
        <div className="flex gap-2">
          <input value={shopName} onChange={(e) => setShopName(e.target.value)}
            className="flex-1 px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "var(--border)" }} />
          <button onClick={saveShopName} className="btn-primary px-4 rounded-xl text-sm font-semibold">ذخیره</button>
        </div>
      </div>

      <div className="card p-4 mb-4">
        <div className="flex items-start gap-2 text-xs" style={{ color: "var(--muted)" }}>
          <Clock size={14} className="flex-shrink-0 mt-0.5" />
          <span>دیگه لازم نیست دوره اصلاح رو دستی تنظیم کنی؛ بعد از دو بار مراجعه هر مشتری، برنامه خودش از روی فاصله واقعی اصلاح‌هاش حسابش می‌کنه و روی عکس پروفایلش نشون می‌ده.</span>
        </div>
      </div>

      <div className="card p-4 mb-4">
        <div className="text-xs mb-3" style={{ color: "var(--muted)" }}>ساعات کاری هفتگی</div>
        <div className="space-y-2.5">
          {WEEKDAYS.map((wd, idx) => {
            const cfg = settings.weekHours[idx] || { closed: false, start: "10:00", end: "21:00" };
            return (
              <div key={idx} className="flex items-center gap-2">
                <button onClick={() => setDayCfg(idx, { closed: !cfg.closed })}
                  className="w-16 flex-shrink-0 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[11px] font-medium"
                  style={cfg.closed ? { background: "#F3E1E1", color: "#B23A3A" } : { background: "var(--accent-light)", color: "var(--primary)" }}>
                  {cfg.closed ? <Lock size={11} /> : <Unlock size={11} />} {wd}
                </button>
                {!cfg.closed ? (
                  <>
                    <input type="time" value={cfg.start} onChange={(e) => setDayCfg(idx, { start: e.target.value })}
                      className="flex-1 px-2 py-1.5 rounded-lg border text-xs" dir="ltr" style={{ borderColor: "var(--border)" }} />
                    <span className="text-xs" style={{ color: "var(--muted)" }}>تا</span>
                    <input type="time" value={cfg.end} onChange={(e) => setDayCfg(idx, { end: e.target.value })}
                      className="flex-1 px-2 py-1.5 rounded-lg border text-xs" dir="ltr" style={{ borderColor: "var(--border)" }} />
                  </>
                ) : (
                  <span className="flex-1 text-xs" style={{ color: "var(--muted)" }}>این روز تعطیله</span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="card p-4 mb-4">
        <div className="flex items-center justify-between mb-3">
          <div className="text-xs" style={{ color: "var(--muted)" }}>خدمات و قیمت‌ها</div>
          <button onClick={() => setAddingService((v) => !v)} className="text-xs font-semibold flex items-center gap-1" style={{ color: "var(--primary)" }}>
            <Plus size={13} /> خدمت جدید
          </button>
        </div>

        <div className="space-y-2">
          {services.map((s) => (
            <ServiceRow key={s.id} service={s}
              editing={editingServiceId === s.id}
              onEdit={() => setEditingServiceId(s.id)}
              onCancelEdit={() => setEditingServiceId(null)}
              onSave={(updated) => { setServices((p) => p.map((x) => (x.id === s.id ? updated : x))); setEditingServiceId(null); showToast("خدمت به‌روزرسانی شد"); }}
              onDelete={() => removeService(s.id)} />
          ))}
        </div>

        {addingService && (
          <NewServiceForm onCancel={() => setAddingService(false)}
            onAdd={(sv) => { setServices((p) => [...p, sv]); setAddingService(false); showToast("خدمت اضافه شد"); }} />
        )}
      </div>

      <div className="card p-4 mb-4">
        <div className="text-xs mb-1" style={{ color: "var(--muted)" }}>پشتیبان‌گیری</div>
        <p className="text-[11px] mb-3" style={{ color: "var(--muted)" }}>
          {toFa(customers.length)} مشتری و {toFa(appointments.length)} نوبت ثبت‌شده. عکس پروفایل و آرشیو مدل‌های مو هم داخل پشتیبان ذخیره می‌شن. برای جلوگیری از دست رفتن اطلاعات (مثلاً موقع تعویض گوشی) هر چند وقت یک‌بار پشتیبان بگیر.
        </p>
        <div className="flex gap-2">
          <button onClick={exportBackup} className="btn-primary flex-1 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5">
            <Download size={14} /> دانلود نسخه پشتیبان
          </button>
          <button onClick={() => fileRef.current?.click()} className="flex-1 py-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5" style={{ borderColor: "var(--border)" }}>
            <Upload size={14} /> بازیابی از فایل
          </button>
          <input ref={fileRef} type="file" accept="application/json" onChange={pickRestoreFile} className="hidden" />
        </div>
      </div>

      {confirmRestore && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 px-4" onClick={() => setConfirmRestore(null)}>
          <div className="card w-full max-w-md p-5 fade-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck size={18} style={{ color: "var(--accent)" }} />
              <div className="font-semibold text-sm">بازیابی نسخه پشتیبان</div>
            </div>
            <p className="text-xs leading-6" style={{ color: "var(--muted)" }}>
              با این کار، اطلاعات فعلی (مشتریان، نوبت‌ها، تنظیمات و خدمات) با محتوای این فایل جایگزین می‌شه. مطمئنی؟
            </p>
            <div className="flex gap-2 mt-4">
              <button onClick={() => { onRestore(confirmRestore); setConfirmRestore(null); }} className="btn-primary flex-1 py-2.5 rounded-xl text-sm font-semibold">بله، بازیابی کن</button>
              <button onClick={() => setConfirmRestore(null)} className="flex-1 py-2.5 rounded-xl text-sm font-semibold border" style={{ borderColor: "var(--border)" }}>انصراف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ServiceRow({ service, editing, onEdit, onCancelEdit, onSave, onDelete }) {
  const [name, setName] = useState(service.name);
  const [duration, setDuration] = useState(service.duration);
  const [price, setPrice] = useState(service.price);
  const [confirmDel, setConfirmDel] = useState(false);

  if (editing) {
    return (
      <div className="rounded-xl p-3" style={{ background: "var(--bg)" }}>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="نام خدمت"
          className="w-full px-2.5 py-2 rounded-lg border text-sm mb-2" style={{ borderColor: "var(--border)" }} />
        <div className="flex gap-2 mb-2">
          <input type="number" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="مدت (دقیقه)" dir="ltr"
            className="flex-1 px-2.5 py-2 rounded-lg border text-sm" style={{ borderColor: "var(--border)" }} />
          <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="قیمت (تومان)" dir="ltr"
            className="flex-1 px-2.5 py-2 rounded-lg border text-sm" style={{ borderColor: "var(--border)" }} />
        </div>
        <div className="flex gap-2">
          <button onClick={() => name.trim() && onSave({ ...service, name: name.trim(), duration: Number(duration) || 15, price: Number(price) || 0 })}
            className="btn-primary flex-1 py-2 rounded-lg text-xs font-semibold">ذخیره</button>
          <button onClick={onCancelEdit} className="flex-1 py-2 rounded-lg text-xs font-semibold border" style={{ borderColor: "var(--border)" }}>انصراف</button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl p-3 flex items-center justify-between" style={{ background: "var(--bg)" }}>
      <div>
        <div className="text-sm font-medium">{service.name}</div>
        <div className="text-[11px] mt-0.5" style={{ color: "var(--muted)" }}>{toFa(service.duration)} دقیقه · {formatToman(service.price)} ت</div>
      </div>
      {!confirmDel ? (
        <div className="flex items-center gap-1">
          <button onClick={onEdit} className="p-1.5 rounded-full" style={{ color: "var(--primary)" }}><Edit3 size={14} /></button>
          <button onClick={() => setConfirmDel(true)} className="p-1.5 rounded-full" style={{ color: "#B23A3A" }}><Trash2 size={14} /></button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <button onClick={onDelete} className="text-[11px] font-semibold" style={{ color: "#B23A3A" }}>حذف؟</button>
          <button onClick={() => setConfirmDel(false)} className="text-[11px]" style={{ color: "var(--muted)" }}>خیر</button>
        </div>
      )}
    </div>
  );
}

function NewServiceForm({ onAdd, onCancel }) {
  const [name, setName] = useState("");
  const [duration, setDuration] = useState(30);
  const [price, setPrice] = useState(150000);
  return (
    <div className="rounded-xl p-3 mt-2" style={{ background: "var(--bg)" }}>
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="نام خدمت (مثلاً کوتاهی ریش)"
        className="w-full px-2.5 py-2 rounded-lg border text-sm mb-2" style={{ borderColor: "var(--border)" }} />
      <div className="flex gap-2 mb-2">
        <input type="number" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="مدت (دقیقه)" dir="ltr"
          className="flex-1 px-2.5 py-2 rounded-lg border text-sm" style={{ borderColor: "var(--border)" }} />
        <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="قیمت (تومان)" dir="ltr"
          className="flex-1 px-2.5 py-2 rounded-lg border text-sm" style={{ borderColor: "var(--border)" }} />
      </div>
      <div className="flex gap-2">
        <button onClick={() => name.trim() && onAdd({ id: uid(), name: name.trim(), duration: Number(duration) || 15, price: Number(price) || 0 })}
          className="btn-gold flex-1 py-2 rounded-lg text-xs font-semibold">افزودن</button>
        <button onClick={onCancel} className="flex-1 py-2 rounded-lg text-xs font-semibold border" style={{ borderColor: "var(--border)" }}>انصراف</button>
      </div>
    </div>
  );
}

function ComposeSmsModal({ customer, onClose, onSent }) {
  const [text, setText] = useState(`سلام ${customer.name.split(" ")[0]} عزیز 👋\nمدتیه به آرایشگاه ما سر نزدید، دلمون براتون تنگ شده!\nهر وقت وقت داشتید منتظرتون هستیم 🙌`);
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <div className="card w-full max-w-md p-5 fade-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <div className="font-semibold text-sm">پیامک به {customer.name}</div>
          <button onClick={onClose}><X size={18} style={{ color: "var(--muted)" }} /></button>
        </div>
        <textarea value={text} onChange={(e) => setText(e.target.value)} rows={5}
          className="w-full px-3 py-2.5 rounded-xl border text-sm resize-none" style={{ borderColor: "var(--border)" }} />
        <p className="text-[11px] mt-2" style={{ color: "var(--muted)" }}>برای ارسال واقعی پیامک، اتصال به یک سرویس پیامکی (مثل کاوه‌نگار) لازمه؛ فعلاً این دکمه فقط برای تست است.</p>
        <div className="flex gap-2 mt-4">
          <button onClick={onSent} className="btn-primary flex-1 py-2.5 rounded-xl text-sm font-semibold">ارسال پیامک</button>
          <a href={`tel:${customer.phone}`} className="px-4 py-2.5 rounded-xl text-sm font-semibold border flex items-center gap-1.5" style={{ borderColor: "var(--border)" }}>
            <PhoneCall size={15} /> تماس
          </a>
        </div>
      </div>
    </div>
  );
}

// ---------- نصب اپ رو صفحه ----------
createRoot(document.getElementById("root")).render(<BarberApp />);

// ثبت service worker برای اجرای آفلاین بعد از اولین بار باز شدن
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  });
}
