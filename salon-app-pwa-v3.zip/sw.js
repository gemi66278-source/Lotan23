// نسخه‌ی کش رو هر بار که فایل‌ها رو عوض کردی عوض کن تا مرورگر نسخه‌ی جدید رو بگیره
const CACHE_NAME = "barbershop-cache-v4";

// پوسته‌ی اصلی برنامه - همه‌چیز محلیه، هیچ فایلی از CDN خارجی نمیاد
const APP_SHELL = [
  "./",
  "./index.html",
  "./app.bundle.js",
  "./styles/tailwind.css",
  "./manifest.json",
  "./offline.html",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-192.png",
  "./icons/icon-maskable-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    )
  );
  self.clients.claim();
});

// استراتژی: اول شبکه رو امتحان کن (تا همیشه آخرین نسخه بیاد)، اگه آفلاین بودی از کش بخون
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;

  const isNavigation = event.request.mode === "navigate";

  event.respondWith(
    fetch(event.request)
      .then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, resClone)).catch(() => {});
        return res;
      })
      .catch(async () => {
        const cached = await caches.match(event.request);
        if (cached) return cached;
        if (isNavigation) {
          const shell = await caches.match("./index.html");
          return shell || caches.match("./offline.html");
        }
        return Response.error();
      })
  );
});

// وقتی نسخه‌ی جدید سرویس‌ورکر آماده شد، صفحه می‌تونه با postMessage بگه فوراً فعال بشه
self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});
